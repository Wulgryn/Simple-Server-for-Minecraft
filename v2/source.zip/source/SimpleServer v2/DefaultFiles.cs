﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v2
{
    class DefaultFiles
    {
        public static String appdata = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        public static String AppPath;
        public static String DefServerSavePath;
        public static String DataFilePath;
        public static String ServerVersionsPath;
        public static String StartUpLoadServers;
        public static String SavedSeedsPath;
        public static String ngrokPath;
        public DefaultFiles(Form f)
        {
            AppPath = appdata + @"\SimpleServer";
            DefServerSavePath = AppPath + @"\Servers";
            DataFilePath = AppPath + @"\data.json";
            ServerVersionsPath = AppPath + @"\Versions";
            StartUpLoadServers = AppPath + @"\bin";
            SavedSeedsPath = AppPath + @"\seeds.json";
            ngrokPath = AppPath + @"\ngrok";

            FolderChecker(AppPath);
            FolderChecker(DefServerSavePath);
            FolderChecker(ServerVersionsPath);
            FolderChecker(StartUpLoadServers);
            FolderChecker(ngrokPath);
            FileChecker(DataFilePath,DefServerSavePath);
            FileChecker(SavedSeedsPath, "");
            if (!File.Exists(AppPath + "\\portType.json"))
            {
                PortType pt = new PortType(f);
                pt.Show();
                pt.TopLevel = true;
            }
            f.Enabled = true;
        }
        private void FileChecker(String path,String text)
        {
            if (!File.Exists(path))
            {
                using(StreamWriter sw = new StreamWriter(path))
                {
                    sw.Write(text);
                    sw.Flush();
                    sw.Close();
                }
            }
        }
        private void FolderChecker(String path)
        {
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        }
    }
}
