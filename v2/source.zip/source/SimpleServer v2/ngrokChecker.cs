﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v2
{
    class ngrokChecker
    {
        public ngrokChecker(Form f)
        {
            if (File.Exists(DefaultFiles.ngrokPath + "\\ngrok.exe"))
            {
                f.Enabled = true;
                return;
            }
            WebClient client = new WebClient();
            client.DownloadFileAsync(new Uri("https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-windows-amd64.zip"),DefaultFiles.AppPath + "\\ngrok.zip");
            client.DownloadProgressChanged += (o, ex) =>
            {
                SimpleServer.dwnldLabel.Text = ex.ProgressPercentage + "%";
            };
            client.DownloadFileCompleted += (o, ex) =>
            {
                if(!File.Exists(DefaultFiles.ngrokPath))ZipFile.ExtractToDirectory(DefaultFiles.AppPath + "\\ngrok.zip",DefaultFiles.ngrokPath);
                SimpleServer.dwnldLabel.Text = "Completed!";
                File.Delete(DefaultFiles.AppPath + "\\ngrok.zip");
                f.Enabled = true;
            };
        }
    }
}
