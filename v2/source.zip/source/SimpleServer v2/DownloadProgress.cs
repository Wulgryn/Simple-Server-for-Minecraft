﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v2
{
    public partial class DownloadProgress : Form
    {
        private Form form;
        private string url;
        private string path;
        private string ver;
        private WebClient client;
        public DownloadProgress(Form f,string link,string to,string version)
        {
            InitializeComponent();
            form = f;
            url = link;
            path = to;
            ver = version;
        }

        private void StartDownload()
        {
            client = new WebClient();
            client.DownloadFileAsync(new Uri(url),path + ver + @"\spigot.jar");
            client.DownloadProgressChanged += (o,ex) =>
            {
                DownloadProgressBar.Value = ex.ProgressPercentage;
                percentage.Text = ex.ProgressPercentage + "%";
            };
            client.DownloadFileCompleted += (o, ex) =>
            {
                SimpleServer.dwnldBTN.Visible = false;
                if (ex.Cancelled)
                {
                    Directory.Delete(path + ver,true);
                    SimpleServer.dwnldBTN.Visible = true;
                }
                form.Enabled = true;
                this.Dispose();
            };
        }

        private void DownloadProgress_Load(object sender, EventArgs e)
        {
            StartDownload();
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            client.CancelAsync();
        }
    }
}
