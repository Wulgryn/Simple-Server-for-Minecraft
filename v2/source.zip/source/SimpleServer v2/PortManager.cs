﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Mono.Nat;

namespace SimpleServer_v2
{
    public partial class PortManager : Form
    {
        private Form f;
        public PortManager(Form form)
        {
            InitializeComponent();
            f = form;
        }

        private void PortManager_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Please only use this if you know what you are doing.","WARNING");
        }
        private void port_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(port.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                port.Text = port.Text.Remove(port.Text.Length - 1);
                port.SelectionStart = port.Text.Length;
            }
            if (port.Text.Length > 5)
            {
                MessageBox.Show("Max length 5 characters.");
                port.Text = port.Text.Remove(port.Text.Length - 1);
                port.SelectionStart = port.Text.Length;
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            f.Enabled = true;
        }

        private void Add_Click(object sender, EventArgs e)
        {
            if(port.Text == "")
            {
                MessageBox.Show("Please enter the port.", "WARNING");
                return;
            }
            NatUtility.DeviceFound += (o, ex) =>
            {
                ex.Device.CreatePortMap(new Mapping(Protocol.Tcp, int.Parse(port.Text), int.Parse(port.Text)));
                //NatUtility.StopDiscovery();
                this.Invoke(new Action(() => { port.Text = ""; }));
            };
            NatUtility.StartDiscovery();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (port.Text == "")
            {
                MessageBox.Show("Please enter the port.", "WARNING");
                return;
            }
            NatUtility.DeviceFound += (o, ex) =>
            {
                ex.Device.DeletePortMap(new Mapping(Protocol.Tcp, int.Parse(port.Text), int.Parse(port.Text)));
                NatUtility.StopDiscovery();
                this.Invoke(new Action(() => { port.Text = ""; }));
            };
            NatUtility.StartDiscovery();
        }
    }
}
