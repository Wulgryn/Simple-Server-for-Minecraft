﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v2
{
    public partial class SeedLoader : Form
    {
        string[] seeds;
        Form form;
        TextBox textBox;
        public SeedLoader(Form f,TextBox tb)
        {
            InitializeComponent();
            form = f;
            textBox = tb;
        }
        private void SeedLoader_Load(object sender, EventArgs e)
        {
            LoadSeeds();
        }
        private void LoadSeeds()
        {
            seedList.Controls.Clear();
            using (StreamReader sr = new StreamReader(DefaultFiles.SavedSeedsPath))
            {
                seeds = sr.ReadToEnd().Split('\n');
            }
            int i = 0;
            foreach (string s in seeds)
            {
                if (s == "" || s == "\n" || s == "\r") return;
                string name = s.Split(':')[0];
                string seed = s.Split(':')[1];
                #region main panel
                Panel mainPanel = new Panel();
                mainPanel.Name = name;
                mainPanel.Size = new Size(553, 41);
                mainPanel.Location = new Point(0, i * 47);
                mainPanel.BackColor = Color.FromArgb(192, 255, 255);
                seedList.Controls.Add(mainPanel);
                #endregion
                #region name
                Label seedName = new Label();
                seedName.Text = name;
                seedName.Font = new Font("Microsoft Sans Serif", 12);
                seedName.Size = new Size(178, 20);
                seedName.Location = new Point(12, 11);
                mainPanel.Controls.Add(seedName);
                #endregion
                #region seed
                LinkLabel seedValue = new LinkLabel();
                seedValue.Text = seed;
                seedValue.Font = new Font("Microsoft Sans Serif", 12);
                seedValue.Location = new Point(191, 12);
                seedValue.Size = new Size(200, 18);
                seedValue.Click += (o, ex) =>
                {
                    Clipboard.SetText(seed);
                };
                mainPanel.Controls.Add(seedValue);
                #endregion
                #region set
                Button set = new Button();
                set.Text = "Set";
                set.Location = new Point(539, 0);
                set.Size = new Size(34, 41);
                set.Dock = DockStyle.Right;
                set.Click += (o, ex) =>
                {
                    form.Enabled = true;
                    textBox.Text = seed;
                    using (StreamWriter sw = new StreamWriter(DefaultFiles.SavedSeedsPath))
                    {
                        foreach (string ss in seeds)
                        {
                            if (ss != "" && ss != "\n" && ss != "\r") sw.WriteLine(ss.Split('\n', '\r')[0]);
                        }
                    }
                    this.Dispose();
                };
                set.FlatStyle = FlatStyle.Flat;
                set.BackColor = Color.FromArgb(192, 255, 192);
                mainPanel.Controls.Add(set);
                #endregion
                #region del
                Button del = new Button();
                del.Text = "Del";
                del.Size = new Size(34, 41);
                del.Name = "" + i;
                del.Location = new Point(539, 0);
                del.Dock = DockStyle.Right;
                del.Click += (o, ex) =>
                {
                    DialogResult dr = MessageBox.Show("Do you realy want to delete this seed?", "WARNING", MessageBoxButtons.YesNo);
                    if (dr == DialogResult.Yes)
                    {
                        seeds[int.Parse(del.Name)] = "";
                        using (StreamWriter sw = new StreamWriter(DefaultFiles.SavedSeedsPath))
                        {
                            foreach (string ss in seeds)
                            {
                                if (ss != "" && ss != "\n" && ss != "\r") sw.WriteLine(ss.Split('\n', '\r')[0]);
                            }
                        }
                        LoadSeeds();
                    }
                };
                del.FlatStyle = FlatStyle.Flat;
                del.BackColor = Color.FromArgb(192, 255, 192);
                mainPanel.Controls.Add(del);
                #endregion
                i++;
            }
        }
        private void Add_Click(object sender, EventArgs e)
        {
            if(SeedName.Text == "")
            {
                MessageBox.Show("Please enter name.","WARNING");
                return;
            }
            if (SeedVal.Text == "")
            {
                MessageBox.Show("Please enter seed.", "WARNING");
                return;
            }
            using (StreamWriter sw = new StreamWriter(DefaultFiles.SavedSeedsPath))
            {
                foreach (string s in seeds)
                {
                    if (s != "" && s != "\n" && s != "\r") sw.WriteLine(s.Split('\n', '\r')[0]);
                }
                sw.WriteLine(SeedName.Text + ":" + SeedVal.Text);
            }
            SeedName.Text = "";
            SeedVal.Text = "";
            LoadSeeds();
        }
        protected override void OnClosed(EventArgs e)
        {
            using (StreamWriter sw = new StreamWriter(DefaultFiles.SavedSeedsPath))
            {
                foreach (string s in seeds)
                {
                    if (s != "" && s != "\n" && s != "\r") sw.WriteLine(s.Split('\n', '\r')[0]);
                }
            }
            form.Enabled = true;
        }
    }
}
