﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v2
{
    class NewServerVersionHandler
    {
        public static string[][] SpigotVersions = new string[][] {
                                                        new string[]{"1.17","https://download.getbukkit.org/spigot/spigot-1.17.jar"},
                                                        new string[]{"1.16.5","https://cdn.getbukkit.org/spigot/spigot-1.16.5.jar"},
                                                        new string[]{"1.16.4","https://cdn.getbukkit.org/spigot/spigot-1.16.4.jar"},
                                                        new string[]{"1.16.3","https://cdn.getbukkit.org/spigot/spigot-1.16.3.jar"},
                                                        new string[]{"1.16.2","https://cdn.getbukkit.org/spigot/spigot-1.16.2.jar"},
                                                        new string[]{"1.16.1","https://cdn.getbukkit.org/spigot/spigot-1.16.1.jar"},
                                                        new string[]{"1.15.2","https://cdn.getbukkit.org/spigot/spigot-1.15.2.jar"},
                                                        new string[]{"1.15.1","https://cdn.getbukkit.org/spigot/spigot-1.15.1.jar"},
                                                        new string[]{"1.15","https://cdn.getbukkit.org/spigot/spigot-1.15.jar"},
                                                        new string[]{"1.14.4","https://cdn.getbukkit.org/spigot/spigot-1.14.4.jar"},
                                                        new string[]{"1.14.3","https://cdn.getbukkit.org/spigot/spigot-1.14.3.jar"},
                                                        new string[]{"1.14.2","https://cdn.getbukkit.org/spigot/spigot-1.14.2.jar"},
                                                        new string[]{"1.14.1","https://cdn.getbukkit.org/spigot/spigot-1.14.1.jar"},
                                                        new string[]{"1.14","https://cdn.getbukkit.org/spigot/spigot-1.14.jar"},
                                                        new string[]{"1.13.2","https://cdn.getbukkit.org/spigot/spigot-1.13.2.jar"},
                                                        new string[]{"1.13.1","https://cdn.getbukkit.org/spigot/spigot-1.13.1.jar"},
                                                        new string[]{"1.13","https://cdn.getbukkit.org/spigot/spigot-1.13.jar"},
                                                        new string[]{"1.12.2","https://cdn.getbukkit.org/spigot/spigot-1.12.2.jar"},
                                                        new string[]{"1.12.1","https://cdn.getbukkit.org/spigot/spigot-1.12.1.jar"},
                                                        new string[]{"1.12","https://cdn.getbukkit.org/spigot/spigot-1.12.jar"},
                                                        new string[]{"1.11.2","https://cdn.getbukkit.org/spigot/spigot-1.11.2.jar"},
                                                        new string[]{"1.11.1","https://cdn.getbukkit.org/spigot/spigot-1.11.1.jar"},
                                                        new string[]{"1.11","https://cdn.getbukkit.org/spigot/spigot-1.11.jar"},
                                                        new string[]{"1.10.2","https://cdn.getbukkit.org/spigot/spigot-1.10.2-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.10","https://cdn.getbukkit.org/spigot/spigot-1.10-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.9.4","https://cdn.getbukkit.org/spigot/spigot-1.9.4-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.9.2","https://cdn.getbukkit.org/spigot/spigot-1.9.2-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.9","https://cdn.getbukkit.org/spigot/spigot-1.9-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8.8","https://cdn.getbukkit.org/spigot/spigot-1.8.8-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8.7","https://cdn.getbukkit.org/spigot/spigot-1.8.7-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8.6","https://cdn.getbukkit.org/spigot/spigot-1.8.6-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8.5","https://cdn.getbukkit.org/spigot/spigot-1.8.5-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8.4","https://cdn.getbukkit.org/spigot/spigot-1.8.4-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8.3","https://cdn.getbukkit.org/spigot/spigot-1.8.3-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8","https://cdn.getbukkit.org/spigot/spigot-1.8-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.7.10","https://cdn.getbukkit.org/spigot/spigot-1.7.10-SNAPSHOT-b1657.jar"},
                                                        new string[]{"1.7.9","https://cdn.getbukkit.org/spigot/spigot-1.7.9-R0.2-SNAPSHOT.jar"},
                                                        new string[]{"1.7.8","https://cdn.getbukkit.org/spigot/spigot-1.7.8-R0.1-SNAPSHOT.jar"},
                                                        new string[]{"1.7.5","https://cdn.getbukkit.org/spigot/spigot-1.7.5-R0.1-SNAPSHOT-1387.jar"},
                                                        new string[]{"1.7.2","https://cdn.getbukkit.org/spigot/spigot-1.7.2-R0.4-SNAPSHOT-1339.jar"},
                                                        new string[]{"1.6.4","https://cdn.getbukkit.org/spigot/spigot-1.6.4-R2.1-SNAPSHOT.jar"},
                                                        new string[]{"1.6.2","https://cdn.getbukkit.org/spigot/spigot-1.6.2-R1.1-SNAPSHOT.jar"},
                                                        new string[]{"1.5.2","https://cdn.getbukkit.org/spigot/spigot-1.5.2-R1.1-SNAPSHOT.jar"},
                                                        new string[]{"1.5.1","https://cdn.getbukkit.org/spigot/spigot-1.5.1-R0.1-SNAPSHOT.jar"},
                                                        new string[]{"1.4.7","https://cdn.getbukkit.org/spigot/spigot-1.4.7-R1.1-SNAPSHOT.jar"},
                                                        new string[]{"1.4.6","https://cdn.getbukkit.org/spigot/spigot-1.4.6-R0.4-SNAPSHOT.jar"},
                                                                    };
        private string[][] ForgeVersions = new string[][] { new string[] { "1.16.5 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.16.5-36.1.16/forge-1.16.5-36.1.16-installer.jar" },
                                                            new string[] { "1.16.4 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.16.4-35.1.37/forge-1.16.4-35.1.37-installer.jar" },
                                                            new string[] { "1.16.3 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.16.3-34.1.42/forge-1.16.3-34.1.42-installer.jar" },
                                                            new string[] { "1.16.2 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.16.2-33.0.61/forge-1.16.2-33.0.61-installer.jar" },
                                                            new string[] { "1.16.1 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.16.1-32.0.108/forge-1.16.1-32.0.108-installer.jar" },
                                                            new string[] { "1.15.2 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.15.2-31.2.50/forge-1.15.2-31.2.50-installer.jar" },
                                                            new string[] { "1.15.1 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.15.1-30.0.51/forge-1.15.1-30.0.51-installer.jar" },
                                                            new string[] { "1.15 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.15-29.0.4/forge-1.15-29.0.4-installer.jar" },
                                                            new string[] { "1.14.4 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.14.4-28.2.23/forge-1.14.4-28.2.23-installer.jar" },
                                                            new string[] { "1.14.3 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.14.3-27.0.60/forge-1.14.3-27.0.60-installer.jar" },
                                                            new string[] { "1.14.2 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.14.2-26.0.63/forge-1.14.2-26.0.63-installer.jar" },
                                                            new string[] { "1.13.2 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.13.2-25.0.219/forge-1.13.2-25.0.219-installer.jar" },
                                                            new string[] { "1.12.2 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.12.2-14.23.5.2855/forge-1.12.2-14.23.5.2855-installer.jar" },
                                                            new string[] { "1.12.1 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.12.1-14.22.1.2485/forge-1.12.1-14.22.1.2485-installer.jar" },
                                                            new string[] { "1.12 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.12-14.21.1.2443/forge-1.12-14.21.1.2443-installer.jar" },
                                                            new string[] { "1.11.2 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.11.2-13.20.1.2588/forge-1.11.2-13.20.1.2588-installer.jar" },
                                                            new string[] { "1.11 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.11-13.19.1.2199/forge-1.11-13.19.1.2199-installer.jar" },
                                                            new string[] { "1.10.2 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.10.2-12.18.3.2511/forge-1.10.2-12.18.3.2511-installer.jar" },
                                                            new string[] { "1.10 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.10-12.18.0.2000/forge-1.10-12.18.0.2000-installer.jar" },
                                                            new string[] { "1.9.4 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.9.4-12.17.0.2317/forge-1.9.4-12.17.0.2317-installer.jar" },
                                                            new string[] { "1.9 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.9-12.16.1.1938/forge-1.9-12.16.1.1938-installer.jar" },
                                                            new string[] { "1.8.9 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.8.9-11.15.1.2318/forge-1.8.9-11.15.1.2318-installer.jar" },
                                                            new string[] { "1.8.8 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.8.8-11.15.0.1655/forge-1.8.8-11.15.0.1655-installer.jar" },
                                                            new string[] { "1.8 - forge", "https://maven.minecraftforge.net/net/minecraftforge/forge/1.8-11.14.4.1577/forge-1.8-11.14.4.1577-installer.jar" },
                                                            };
        public static bool LoadForgeVers = false;
        public NewServerVersionHandler()
        {
            LoadVersions();
        }

        private void LoadVersions()
        {
            SimpleServer.vers.Items.Clear();
            if(!LoadForgeVers)
            {
                foreach (string[] s in SpigotVersions)
                {
                    SimpleServer.vers.Items.Add(s[0]);
                }
                SimpleServer.vers.SelectedIndex = 0;
            }
            else
            {
                foreach (string[] s in ForgeVersions)
                {
                    SimpleServer.vers.Items.Add(s[0]);
                }
                SimpleServer.vers.SelectedIndex = 0;
            }
        }

        
    }
}
