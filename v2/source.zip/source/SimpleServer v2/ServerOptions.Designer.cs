﻿
namespace SimpleServer_v2
{
    partial class ServerOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cancel = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.port = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.OnlineMode = new System.Windows.Forms.CheckBox();
            this.CommandBlocks = new System.Windows.Forms.CheckBox();
            this.Hardcore = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.MaxPlayers = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.seed = new System.Windows.Forms.TextBox();
            this.RecreateWorld = new System.Windows.Forms.CheckBox();
            this.RecreateNether = new System.Windows.Forms.CheckBox();
            this.RecreateEnd = new System.Windows.Forms.CheckBox();
            this.OpenDirectory = new System.Windows.Forms.Button();
            this.motd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Delete = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.EnableProperties = new System.Windows.Forms.CheckBox();
            this.properties = new System.Windows.Forms.RichTextBox();
            this.AcceptChanges = new System.Windows.Forms.CheckBox();
            this.Advanced = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.worldName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ServerName = new System.Windows.Forms.TextBox();
            this.ChangeDisplayName = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.MaxPlayers)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(199, 338);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 0;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(114, 338);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(75, 23);
            this.Save.TabIndex = 1;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // port
            // 
            this.port.Location = new System.Drawing.Point(38, 25);
            this.port.Name = "port";
            this.port.Size = new System.Drawing.Size(100, 20);
            this.port.TabIndex = 3;
            this.port.Text = "25565";
            this.port.TextChanged += new System.EventHandler(this.port_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Port:";
            // 
            // OnlineMode
            // 
            this.OnlineMode.AutoSize = true;
            this.OnlineMode.Checked = true;
            this.OnlineMode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.OnlineMode.Location = new System.Drawing.Point(6, 97);
            this.OnlineMode.Name = "OnlineMode";
            this.OnlineMode.Size = new System.Drawing.Size(85, 17);
            this.OnlineMode.TabIndex = 5;
            this.OnlineMode.Text = "Online mode";
            this.OnlineMode.UseVisualStyleBackColor = true;
            this.OnlineMode.CheckedChanged += new System.EventHandler(this.OnlineMode_CheckedChanged);
            // 
            // CommandBlocks
            // 
            this.CommandBlocks.AutoSize = true;
            this.CommandBlocks.Location = new System.Drawing.Point(6, 120);
            this.CommandBlocks.Name = "CommandBlocks";
            this.CommandBlocks.Size = new System.Drawing.Size(142, 17);
            this.CommandBlocks.TabIndex = 6;
            this.CommandBlocks.Text = "Enable command blocks";
            this.CommandBlocks.UseVisualStyleBackColor = true;
            this.CommandBlocks.CheckedChanged += new System.EventHandler(this.CommandBlocks_CheckedChanged);
            // 
            // Hardcore
            // 
            this.Hardcore.AutoSize = true;
            this.Hardcore.Location = new System.Drawing.Point(6, 143);
            this.Hardcore.Name = "Hardcore";
            this.Hardcore.Size = new System.Drawing.Size(70, 17);
            this.Hardcore.TabIndex = 7;
            this.Hardcore.Text = "Hardcore";
            this.Hardcore.UseVisualStyleBackColor = true;
            this.Hardcore.CheckedChanged += new System.EventHandler(this.Hardcore_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Max players:";
            // 
            // MaxPlayers
            // 
            this.MaxPlayers.Location = new System.Drawing.Point(68, 71);
            this.MaxPlayers.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.MaxPlayers.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.MaxPlayers.Name = "MaxPlayers";
            this.MaxPlayers.Size = new System.Drawing.Size(120, 20);
            this.MaxPlayers.TabIndex = 10;
            this.MaxPlayers.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.MaxPlayers.ValueChanged += new System.EventHandler(this.MaxPlayers_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Seed:";
            // 
            // seed
            // 
            this.seed.Location = new System.Drawing.Point(38, 48);
            this.seed.Name = "seed";
            this.seed.Size = new System.Drawing.Size(270, 20);
            this.seed.TabIndex = 12;
            this.seed.TextChanged += new System.EventHandler(this.seed_TextChanged);
            // 
            // RecreateWorld
            // 
            this.RecreateWorld.AutoSize = true;
            this.RecreateWorld.Location = new System.Drawing.Point(6, 76);
            this.RecreateWorld.Name = "RecreateWorld";
            this.RecreateWorld.Size = new System.Drawing.Size(108, 17);
            this.RecreateWorld.TabIndex = 13;
            this.RecreateWorld.Text = "Delete Overworld";
            this.RecreateWorld.UseVisualStyleBackColor = true;
            // 
            // RecreateNether
            // 
            this.RecreateNether.AutoSize = true;
            this.RecreateNether.Location = new System.Drawing.Point(114, 76);
            this.RecreateNether.Name = "RecreateNether";
            this.RecreateNether.Size = new System.Drawing.Size(92, 17);
            this.RecreateNether.TabIndex = 14;
            this.RecreateNether.Text = "Delete Nether";
            this.RecreateNether.UseVisualStyleBackColor = true;
            // 
            // RecreateEnd
            // 
            this.RecreateEnd.AutoSize = true;
            this.RecreateEnd.Location = new System.Drawing.Point(212, 76);
            this.RecreateEnd.Name = "RecreateEnd";
            this.RecreateEnd.Size = new System.Drawing.Size(79, 17);
            this.RecreateEnd.TabIndex = 15;
            this.RecreateEnd.Text = "Delete End";
            this.RecreateEnd.UseVisualStyleBackColor = true;
            // 
            // OpenDirectory
            // 
            this.OpenDirectory.Location = new System.Drawing.Point(7, 338);
            this.OpenDirectory.Name = "OpenDirectory";
            this.OpenDirectory.Size = new System.Drawing.Size(101, 23);
            this.OpenDirectory.TabIndex = 16;
            this.OpenDirectory.Text = "Open Directory";
            this.OpenDirectory.UseVisualStyleBackColor = true;
            this.OpenDirectory.Click += new System.EventHandler(this.OpenDirectory_Click);
            // 
            // motd
            // 
            this.motd.Location = new System.Drawing.Point(6, 179);
            this.motd.Name = "motd";
            this.motd.Size = new System.Drawing.Size(270, 20);
            this.motd.TabIndex = 18;
            this.motd.Text = "A Minecraft Server";
            this.motd.TextChanged += new System.EventHandler(this.motd_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Motd:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.Delete);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.EnableProperties);
            this.panel1.Controls.Add(this.properties);
            this.panel1.Location = new System.Drawing.Point(374, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(325, 361);
            this.panel1.TabIndex = 19;
            // 
            // Delete
            // 
            this.Delete.ForeColor = System.Drawing.Color.Red;
            this.Delete.Location = new System.Drawing.Point(3, 12);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(318, 23);
            this.Delete.TabIndex = 24;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Advanced properties:";
            // 
            // EnableProperties
            // 
            this.EnableProperties.AutoSize = true;
            this.EnableProperties.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.EnableProperties.ForeColor = System.Drawing.Color.Red;
            this.EnableProperties.Location = new System.Drawing.Point(3, 69);
            this.EnableProperties.Name = "EnableProperties";
            this.EnableProperties.Size = new System.Drawing.Size(239, 24);
            this.EnableProperties.TabIndex = 1;
            this.EnableProperties.Text = "Enable properties manual edit";
            this.EnableProperties.UseVisualStyleBackColor = true;
            this.EnableProperties.CheckedChanged += new System.EventHandler(this.EnableProperties_CheckedChanged);
            // 
            // properties
            // 
            this.properties.Location = new System.Drawing.Point(0, 99);
            this.properties.Name = "properties";
            this.properties.ReadOnly = true;
            this.properties.Size = new System.Drawing.Size(321, 265);
            this.properties.TabIndex = 0;
            this.properties.Text = "";
            // 
            // AcceptChanges
            // 
            this.AcceptChanges.AutoSize = true;
            this.AcceptChanges.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.AcceptChanges.ForeColor = System.Drawing.Color.Red;
            this.AcceptChanges.Location = new System.Drawing.Point(6, 205);
            this.AcceptChanges.Name = "AcceptChanges";
            this.AcceptChanges.Size = new System.Drawing.Size(218, 24);
            this.AcceptChanges.TabIndex = 1;
            this.AcceptChanges.Text = "Accept properties changes";
            this.AcceptChanges.UseVisualStyleBackColor = true;
            // 
            // Advanced
            // 
            this.Advanced.Location = new System.Drawing.Point(280, 3);
            this.Advanced.Name = "Advanced";
            this.Advanced.Size = new System.Drawing.Size(85, 23);
            this.Advanced.TabIndex = 20;
            this.Advanced.Text = "Advanced >>>";
            this.Advanced.UseVisualStyleBackColor = true;
            this.Advanced.Click += new System.EventHandler(this.Advanced_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.AcceptChanges);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.port);
            this.panel2.Controls.Add(this.OnlineMode);
            this.panel2.Controls.Add(this.motd);
            this.panel2.Controls.Add(this.CommandBlocks);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.Hardcore);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.MaxPlayers);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.seed);
            this.panel2.Location = new System.Drawing.Point(1, 99);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(373, 233);
            this.panel2.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(2, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "Properties:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 53);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 22;
            this.label7.Text = "World name:";
            // 
            // worldName
            // 
            this.worldName.Location = new System.Drawing.Point(82, 50);
            this.worldName.Name = "worldName";
            this.worldName.Size = new System.Drawing.Size(189, 20);
            this.worldName.TabIndex = 23;
            this.worldName.Text = "world";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 8);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 13);
            this.label8.TabIndex = 24;
            this.label8.Text = "Name:";
            // 
            // ServerName
            // 
            this.ServerName.Location = new System.Drawing.Point(53, 5);
            this.ServerName.Name = "ServerName";
            this.ServerName.Size = new System.Drawing.Size(136, 20);
            this.ServerName.TabIndex = 25;
            this.ServerName.TextChanged += new System.EventHandler(this.ServerName_TextChanged);
            // 
            // ChangeDisplayName
            // 
            this.ChangeDisplayName.AutoSize = true;
            this.ChangeDisplayName.Location = new System.Drawing.Point(12, 27);
            this.ChangeDisplayName.Name = "ChangeDisplayName";
            this.ChangeDisplayName.Size = new System.Drawing.Size(153, 17);
            this.ChangeDisplayName.TabIndex = 26;
            this.ChangeDisplayName.Text = "Change serer display name";
            this.ChangeDisplayName.UseVisualStyleBackColor = true;
            // 
            // ServerOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(374, 364);
            this.Controls.Add(this.ChangeDisplayName);
            this.Controls.Add(this.ServerName);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.worldName);
            this.Controls.Add(this.Advanced);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.OpenDirectory);
            this.Controls.Add(this.RecreateEnd);
            this.Controls.Add(this.RecreateNether);
            this.Controls.Add(this.RecreateWorld);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.Cancel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "ServerOptions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ServerOptions";
            this.Load += new System.EventHandler(this.ServerOptions_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MaxPlayers)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.TextBox port;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox OnlineMode;
        private System.Windows.Forms.CheckBox CommandBlocks;
        private System.Windows.Forms.CheckBox Hardcore;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown MaxPlayers;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox seed;
        private System.Windows.Forms.CheckBox RecreateWorld;
        private System.Windows.Forms.CheckBox RecreateNether;
        private System.Windows.Forms.CheckBox RecreateEnd;
        private System.Windows.Forms.Button OpenDirectory;
        private System.Windows.Forms.TextBox motd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox AcceptChanges;
        private System.Windows.Forms.RichTextBox properties;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox EnableProperties;
        private System.Windows.Forms.Button Advanced;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox worldName;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox ServerName;
        private System.Windows.Forms.CheckBox ChangeDisplayName;
    }
}