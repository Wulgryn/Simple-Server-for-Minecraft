﻿
namespace SimpleServer_v2
{
    partial class PortType
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ngrok = new System.Windows.Forms.Button();
            this.upnp = new System.Windows.Forms.Button();
            this.mport = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ngrok
            // 
            this.ngrok.Location = new System.Drawing.Point(12, 32);
            this.ngrok.Name = "ngrok";
            this.ngrok.Size = new System.Drawing.Size(142, 49);
            this.ngrok.TabIndex = 0;
            this.ngrok.Text = "ngrok\r\n-auto-\r\n-1 server-";
            this.ngrok.UseVisualStyleBackColor = true;
            this.ngrok.Click += new System.EventHandler(this.ngrok_Click);
            // 
            // upnp
            // 
            this.upnp.Location = new System.Drawing.Point(198, 32);
            this.upnp.Name = "upnp";
            this.upnp.Size = new System.Drawing.Size(142, 49);
            this.upnp.TabIndex = 1;
            this.upnp.Text = "UPNP\r\n-auto-\r\n-unlimited server-\r\n";
            this.upnp.UseVisualStyleBackColor = true;
            this.upnp.Click += new System.EventHandler(this.upnp_Click);
            // 
            // mport
            // 
            this.mport.Location = new System.Drawing.Point(393, 32);
            this.mport.Name = "mport";
            this.mport.Size = new System.Drawing.Size(142, 49);
            this.mport.TabIndex = 2;
            this.mport.Text = "manual port\r\n-manual-\r\n-unlimited server-";
            this.mport.UseVisualStyleBackColor = true;
            this.mport.Click += new System.EventHandler(this.mport_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Choose one, you can change it later.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 26);
            this.label2.TabIndex = 4;
            this.label2.Text = "ngrok: With this you can only\r\nrun one server at one time.\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(195, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 39);
            this.label3.TabIndex = 5;
            this.label3.Text = "UPNP: With this te port forward\r\nwill automated. You just have\r\nto enable it in y" +
    "our router.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(390, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 39);
            this.label4.TabIndex = 6;
            this.label4.Text = "manual port: With this you\r\nhave to port forward\r\nmanually in your router.";
            // 
            // PortType
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(545, 136);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mport);
            this.Controls.Add(this.upnp);
            this.Controls.Add(this.ngrok);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "PortType";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PortType";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ngrok;
        private System.Windows.Forms.Button upnp;
        private System.Windows.Forms.Button mport;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}