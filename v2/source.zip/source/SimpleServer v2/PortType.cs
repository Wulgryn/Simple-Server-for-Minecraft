﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v2
{
    public partial class PortType : Form
    {
        private Form form;
        public PortType(Form f)
        {
            InitializeComponent();
            form = f;
        }

        private void ngrok_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you really want to use ngrok?", "WARNING", MessageBoxButtons.YesNo);
            if(dr == DialogResult.Yes)
            {
                SimpleServer.ngrok_ = true;
                SimpleServer.selfPort = false;
                SimpleServer.upnp_ = false;
                ngrokChecker nc = new ngrokChecker(form);
                using (StreamWriter sw = new StreamWriter(DefaultFiles.AppPath + "\\portType.json"))
                {
                    sw.WriteLine("ngrok");
                }
                this.Dispose();
            }
        }

        private void upnp_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you really want to use UPNP?", "WARNING", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                SimpleServer.ngrok_ = false;
                SimpleServer.selfPort = false;
                SimpleServer.upnp_ = true;
                using (StreamWriter sw = new StreamWriter(DefaultFiles.AppPath + "\\portType.json"))
                {
                    sw.WriteLine("upnp");
                }
                form.Enabled = true;
                this.Dispose();
            }
        }

        private void mport_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you really want to use manual port?", "WARNING", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                SimpleServer.ngrok_ = false;
                SimpleServer.selfPort = true;
                SimpleServer.upnp_ = false;
                using (StreamWriter sw = new StreamWriter(DefaultFiles.AppPath + "\\portType.json"))
                {
                    sw.WriteLine("manualport");
                }
                form.Enabled = true;
                this.Dispose();
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            e.Cancel = true;
        }
    }
}
