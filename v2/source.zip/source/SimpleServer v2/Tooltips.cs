﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v2
{
    public partial class Tooltips : Form
    {
        Form form;
        public Tooltips(Form f)
        {
            InitializeComponent();
            form = f;
        }

        protected override void OnClosed(EventArgs e)
        {
            form.Enabled = true;
        }
    }
}
