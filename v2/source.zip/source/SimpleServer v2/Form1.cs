﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Mono.Nat;

namespace SimpleServer_v2
{
    public partial class SimpleServer : Form
    {
        private NewServerVersionHandler nsp;
        public static ComboBox vers;
        public static Button dwnldBTN;
        public static Label dwnldLabel;
        public static bool ngrok_ = false;
        public static bool upnp_ = false;
        public static bool selfPort = false;
        public SimpleServer()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Enabled = false;
            DefaultFiles df = new DefaultFiles(this);
            using (StreamReader sr = new StreamReader(DefaultFiles.DataFilePath))
            {
                ServerDir.Text = sr.ReadLine();
            }
            vers = ServerVersions;
            dwnldBTN = DownloadVersion;
            MaxRamType.SelectedIndex = 1;
            StartRamType.SelectedIndex = 1;
            dwnldLabel = DownloadState;
            
            nsp = new NewServerVersionHandler();
            IP.Text = GetIPAddress();
            LoadServers();
        }
        private void ForgeVersions_CheckedChanged(object sender, EventArgs e)
        {
            NewServerVersionHandler.LoadForgeVers = ForgeVersions.Checked;
            nsp = new NewServerVersionHandler();
        }

        private void ServerVersions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!Directory.Exists(DefaultFiles.ServerVersionsPath + @"\" + ServerVersions.Text)) DownloadVersion.Visible = true;
            else DownloadVersion.Visible = false;
        }

        private void DownloadVersion_Click(object sender, EventArgs e)
        {
            Directory.CreateDirectory(DefaultFiles.ServerVersionsPath + @"\" + ServerVersions.SelectedItem.ToString());
            string path = DefaultFiles.ServerVersionsPath + @"\";
            this.Enabled = false;
            DownloadProgress dp = new DownloadProgress(this, NewServerVersionHandler.SpigotVersions[ServerVersions.SelectedIndex][1], path, ServerVersions.SelectedItem.ToString());
            dp.Show(this);
        }

        private void DownloadVersion_VisibleChanged(object sender, EventArgs e)
        {
            if (DownloadVersion.Visible) DeleteVersion.Visible = false;
            else DeleteVersion.Visible = true;
        }

        private void DeleteVersion_Click(object sender, EventArgs e)
        {
            DialogResult messageBox = MessageBox.Show("Are you sure?", "Warning!", MessageBoxButtons.YesNo);
            if (messageBox != DialogResult.Yes) return;
            Directory.Delete(DefaultFiles.ServerVersionsPath + @"\" + ServerVersions.SelectedItem.ToString(), true);
            DownloadVersion.Visible = true;
        }

        private void BrowseServerDir_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                ServerDir.Text = fbd.SelectedPath;
                using (StreamWriter sw = new StreamWriter(DefaultFiles.DataFilePath))
                {
                    sw.WriteLine(fbd.SelectedPath);
                }
            }
        }

        private void DefPath_Click(object sender, EventArgs e)
        {
            ServerDir.Text = DefaultFiles.DefServerSavePath;
            using (StreamWriter sw = new StreamWriter(DefaultFiles.DataFilePath))
            {
                sw.WriteLine(DefaultFiles.DefServerSavePath);
            }
        }

        private void Import_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Batch Files (*.bat) | *.bat";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                FileInfo fi = new FileInfo(Path.GetFullPath(ofd.FileName));
                string[] files = Directory.GetFiles(fi.DirectoryName, "*.jar");
                if (files.Length == 0)
                {
                    MessageBox.Show("Please create a .jar file for your server.", "WARNING");
                    return;
                }
                if (File.Exists(DefaultFiles.StartUpLoadServers + "\\" + fi.Directory.Name))
                {
                    DialogResult dr = MessageBox.Show(fi.Directory.Name + "\nServer exists with this name!\nDo you want to overwrite it?\nThis server will disappiare forever!(That is a long time)", "WARNING", MessageBoxButtons.YesNo);
                    if (dr == DialogResult.No) return;
                    if (fi.Directory.Parent.FullName == DefaultFiles.DefServerSavePath) return;
                    if (dr == DialogResult.Yes)
                    {
                        if (running.Contains(fi.Directory.Name))
                        {
                            MessageBox.Show("Server is running with this name. Please stop it first!", "WARNING");
                            return;
                        }
                        try
                        {
                            File.Delete(DefaultFiles.StartUpLoadServers + "\\" + fi.Directory.Name);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "ERROR");
                            return;
                        }
                    }
                }
                string[] batFile;
                using (StreamReader sr = new StreamReader(fi.FullName))
                {
                    batFile = sr.ReadToEnd().Split('\n', '\r');
                }
                using (StreamWriter sw = new StreamWriter(fi.FullName))
                {
                    int i = 0;
                    foreach (string s in batFile)
                    {
                        if (s == "nogui") return;
                        if (s.Split(' ').ToList<string>().Contains("java") && !s.Split(' ').ToList<string>().Contains("nogui"))
                        {
                            batFile[i] += " nogui";
                        }
                        if (batFile[i] != "\n" && batFile[i] != "" && batFile[i] != "\r") sw.WriteLine(batFile[i]);
                        i++;
                    }
                }
                using (StreamWriter sw = new StreamWriter(DefaultFiles.StartUpLoadServers + "\\" + fi.Directory.Name))
                {
                    sw.WriteLine(fi.FullName);
                    sw.WriteLine(DateTime.Now);
                    sw.WriteLine("Not used");
                    sw.WriteLine("imported");
                }
                LoadServers();
            }
        }

        private void New_Click(object sender, EventArgs e)
        {
            if (ServerName.Text.Length == 0)
            {
                MessageBox.Show("Please enter the server name!", "WARNING");
                return;
            }
            if (ServerName.Text.Length > 50)
            {
                MessageBox.Show("Name too long!\nMax 50 characters.", "WARNING");
                return;
            }
            if (!File.Exists(DefaultFiles.ServerVersionsPath + @"\" + ServerVersions.SelectedItem.ToString() + @"\spigot.jar"))
            {
                MessageBox.Show("Download or reinstall the selected version!", "WARNING");
                return;
            }
            if (!Eula.Checked)
            {
                MessageBox.Show("Please agree to eula!\nhttps://account.mojang.com/documents/minecraft_eula", "WARNING");
                return;
            }
            if (File.Exists(DefaultFiles.StartUpLoadServers + "\\" + ServerName.Text))
            {
                DialogResult dr = MessageBox.Show(ServerName.Text + "\nServer exists with this name!\nDo you want to overwrite it?\nThis server will disappiare forever!(That is a long time)", "WARNING", MessageBoxButtons.YesNo);
                if (dr == DialogResult.No) return;
                if (dr == DialogResult.Yes)
                {
                    if (running.Contains(ServerName.Text))
                    {
                        MessageBox.Show("Server is running with this name. Please stop it first!", "WARNING");
                        return;
                    }
                    string path = "";
                    using (StreamReader sr = new StreamReader(DefaultFiles.StartUpLoadServers + "\\" + ServerName.Text))
                    {
                        path = sr.ReadLine();
                    }
                    FileInfo fi = new FileInfo(path);
                    Directory.Delete(fi.DirectoryName, true);
                }
            }
            Directory.CreateDirectory(ServerDir.Text + "\\" + ServerName.Text);
            string BatFile = "java -jar -Xms" + StartRam.Value + StartRamType.SelectedItem.ToString() + " -Xmx" + MaxRam.Value + MaxRamType.SelectedItem.ToString() + " spigot.jar nogui";
            using (StreamWriter sw = new StreamWriter(ServerDir.Text + "\\" + ServerName.Text + "\\start.bat"))
            {
                sw.WriteLine("@echo off");
                sw.WriteLine(BatFile);
                sw.WriteLine("PAUSE");
            }
            File.Copy(DefaultFiles.ServerVersionsPath + @"\" + ServerVersions.SelectedItem.ToString() + @"\spigot.jar", ServerDir.Text + "\\" + ServerName.Text + "\\spigot.jar", true);
            using (StreamWriter sw = new StreamWriter(ServerDir.Text + "\\" + ServerName.Text + "\\eula.txt"))
            {
                sw.WriteLine("#By changing the setting below to TRUE you are indicating your agreement to our EULA ");
                sw.WriteLine("(https://account.mojang.com/documents/minecraft_eula).");
                sw.WriteLine("#Mon Jan 01 00:00:00 CEST 2021");
                sw.WriteLine("eula=true");
            }
            using (StreamWriter sw = new StreamWriter(ServerDir.Text + "\\" + ServerName.Text + "\\server.properties"))
            {
                sw.WriteLine("#Minecraft server properties");
                sw.WriteLine("#Mon Jan 01 00:00:00 CEST 2021");
                sw.WriteLine("server-port=" + port.Text);
                sw.WriteLine("level-seed=" + seed.Text);
            }
            Eula.Checked = false;
            using (StreamWriter sw = new StreamWriter(DefaultFiles.StartUpLoadServers + "\\" + ServerName.Text))
            {
                sw.WriteLine(ServerDir.Text + "\\" + ServerName.Text + "\\start.bat");
                sw.WriteLine(DateTime.Now);
                sw.WriteLine("Not used");
                sw.WriteLine(ServerVersions.SelectedItem.ToString());
            }
            NatUtility.DeviceFound += (o, ex) =>
            {
                INatDevice device = ex.Device;
                device.CreatePortMap(new Mapping(Protocol.Tcp, int.Parse(port.Text), int.Parse(port.Text)));
            };
            NatUtility.StartDiscovery();
            LoadServers();
        }

        private void EulaLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://account.mojang.com/documents/minecraft_eula");
        }

        private string[] servers;
        public static List<string> running = new List<string>();
        public static List<string> crashed = new List<string>();
        private List<TabPage> consoles_ = new List<TabPage>();

        public void LoadServers()
        {
            ServerList.Controls.Clear();
            servers = Directory.GetFiles(DefaultFiles.StartUpLoadServers);
            int i = 0;
            foreach (string s in servers)
            {
                FileInfo fi = new FileInfo(s);
                Panel mainPanel = new Panel();
                mainPanel.Size = new Size(580, 50);
                mainPanel.Name = fi.Name;
                mainPanel.Location = new Point(3, i * (6 + 50) + 6);
                mainPanel.BorderStyle = BorderStyle.None;
                if (running.Contains(mainPanel.Name)) mainPanel.BackColor = Color.FromArgb(192, 255, 192);
                else mainPanel.BackColor = Color.FromArgb(255, 128, 128);
                if (crashed.Contains(mainPanel.Name)) mainPanel.BackColor = Color.FromArgb(255, 224, 192);


                Label imported = new Label();
                imported.Text = "imported";
                imported.Name = "NULL";
                imported.ForeColor = Color.Silver;
                imported.BackColor = Color.Transparent;
                imported.Font = new Font("Microsoft Sans Serif", 8.25f);
                imported.Location = new Point(3, 33);
                imported.Visible = true;
                imported.Size = new Size(70, 16);
                mainPanel.Controls.Add(imported);

                Label name = new Label();
                name.BackColor = Color.Transparent;
                name.Font = new Font("Microsoft Sans Serif", 8);
                name.Text = fi.Name;
                name.Location = new Point(5, 5);
                name.Size = new Size(380, 20);
                mainPanel.Controls.Add(name);

                Label created = new Label();
                created.BackColor = Color.Transparent;
                created.Font = new Font("Microsoft Sans Serif", 10);
                created.Location = new Point(80, 30);
                created.Size = new Size(155, 16);
                created.ForeColor = Color.Black;
                mainPanel.Controls.Add(created);

                Label last_used = new Label();
                last_used.BackColor = Color.Transparent;
                last_used.Font = new Font("Microsoft Sans Serif", 10);
                last_used.Size = new Size(155, 16);
                last_used.ForeColor = Color.FromArgb(128, 128, 255);
                using (StreamReader sr = new StreamReader(fi.FullName))
                {
                    sr.ReadLine();
                    created.Text = sr.ReadLine();
                    last_used.Text = sr.ReadLine();
                    string line = sr.ReadLine();
                    imported.Text = line;
                    imported.Name = line;
                }
                last_used.Location = new Point(235, 30);
                mainPanel.Controls.Add(last_used);

                Button start = new Button();
                start.FlatStyle = FlatStyle.Flat;
                start.BackColor = Color.FromArgb(192, 255, 255);
                start.Font = new Font("Microsoft Sans Serif", 10);
                start.Text = "Start";

                start.Click += (Object sender, EventArgs args) =>
                {
                    if (running.Contains(mainPanel.Name)) return;
                    TabPage tp = new TabPage();
                    consoles_.Add(tp);
                    string[] lines;
                    string startFile = "";
                    using (StreamReader sr = new StreamReader(fi.FullName))
                    {
                        lines = new string[sr.ReadToEnd().Split('\n').Length];
                    }
                    using (StreamReader sr = new StreamReader(fi.FullName))
                    {
                        for (int j = 0; j < lines.Length; j++)
                        {
                            lines[j] = sr.ReadLine();
                        }
                    }
                    startFile = lines[0];
                    using (StreamWriter sw = new StreamWriter(fi.FullName))
                    {
                        int j = 0;
                        foreach (string ss in lines)
                        {
                            if (j == 2) sw.WriteLine(DateTime.Now);
                            else sw.WriteLine(ss);
                            j++;
                        }
                    }
                    tp.Text = fi.Name + " - Console";
                    tp.Name = tp.Text;

                    RichTextBox consoleBox = new RichTextBox();
                    consoleBox.Dock = DockStyle.Top;
                    consoleBox.Size = new Size(478, 470);
                    consoleBox.BorderStyle = BorderStyle.FixedSingle;
                    consoleBox.Text = "";
                    consoleBox.Enabled = false;
                    tp.Controls.Add(consoleBox);

                    TextBox Input = new TextBox();
                    Input.Dock = DockStyle.Bottom;
                    tp.Controls.Add(Input);

                    consoles.TabPages.Add(tp);
                    bool stop = false;
                    bool saveSeed = false;
                    string seedName = "";
                    FileInfo ff = new FileInfo(startFile);
                    Process p = new Process();
                    p.StartInfo.FileName = "cmd";
                    p.StartInfo.WorkingDirectory = ff.DirectoryName;
                    p.StartInfo.UseShellExecute = false;
                    p.StartInfo.CreateNoWindow = true;
                    p.StartInfo.RedirectStandardError = true;
                    p.StartInfo.RedirectStandardOutput = true;
                    p.StartInfo.RedirectStandardInput = true;
                    p.OutputDataReceived += (send, e) =>
                    {
                        this.Invoke(new Action(() =>
                        {
                            consoleBox.Text += e.Data + "\n";
                            consoleBox.SelectionStart = consoleBox.Text.Length;
                            consoleBox.ScrollToCaret();
                            if (e.Data != null)
                            {
                                if (e.Data.Split(']').Length > 2)
                                {
                                    if (e.Data.Split(']')[2] == ": CONSOLE: Reload complete." && stop)
                                    {
                                        p.StandardInput.WriteLine("stop");
                                        p.Close();
                                        consoles.TabPages.Remove(tp);
                                        running.Remove(mainPanel.Name);
                                        crashed.Remove(mainPanel.Name);
                                        LoadServers();
                                    }
                                }
                                if (saveSeed && !stop)
                                {
                                    string[] seedArray = e.Data.Split('[', ']');
                                    string line = "";
                                    using (StreamReader sr = new StreamReader(DefaultFiles.SavedSeedsPath))
                                    {
                                        line = sr.ReadToEnd();
                                    }
                                    using (StreamWriter sw = new StreamWriter(DefaultFiles.SavedSeedsPath))
                                    {
                                        sw.Write(line);
                                        sw.WriteLine(seedName + ":" + (seedArray[seedArray.Length - 2] == "" ? "Unnamed" : seedArray[seedArray.Length - 2]));
                                    }
                                    saveSeed = false;
                                }
                                try
                                {
                                    if (e.Data.Split(']')[2] == ": Saving worlds" && !stop)
                                    {
                                        if (!crashed.Contains(mainPanel.Name)) crashed.Add(mainPanel.Name);
                                        LoadServers();
                                    }

                                }
                                catch { }
                            }
                        }));
                    };
                    p.ErrorDataReceived += (send, e) =>
                    {
                        this.Invoke(new Action(() =>
                        {
                            consoleBox.Text += e.Data + "\n";
                            consoleBox.SelectionStart = consoleBox.Text.Length;
                            consoleBox.ScrollToCaret();
                            mainPanel.BackColor = Color.FromArgb(255, 224, 192);
                        }));
                    };
                    Input.KeyDown += (o, e) =>
                    {
                        if (e.KeyCode == Keys.Enter)
                        {
                            if (Input.Text == "restart")
                            {
                                consoleBox.Text += "This command is not allowed.\n";
                                Input.Text = "";
                            }
                            if (Input.Text == "close")
                            {
                                p.Close();
                                consoles.TabPages.Remove(tp);
                                running.Remove(mainPanel.Name);
                                crashed.Remove(mainPanel.Name);
                                LoadServers();
                                return;
                            }
                            if (Input.Text == "stop")
                            {
                                stop = true;
                                p.StandardInput.WriteLine("save-all");
                                p.StandardInput.WriteLine("reload");
                                Input.Text = "";
                            }
                            string[] seed = Input.Text.Split(':');
                            if (seed[0] == "saveseed" && seed.Length > 1)
                            {
                                saveSeed = true;
                                seedName = seed[1];
                                p.StandardInput.WriteLine("seed");
                                Input.Text = "";
                            }

                            p.StandardInput.WriteLine(Input.Text);
                            Input.Text = "";
                        }
                    };
                    p.Start();
                    p.BeginErrorReadLine();
                    p.BeginOutputReadLine();
                    p.StandardInput.WriteLine("call " + ff.Name);
                    running.Add(mainPanel.Name);
                    LoadServers();
                };
                start.Size = new Size(70, 43);
                start.Location = new Point(391, 3);
                mainPanel.Controls.Add(start);

                Button console = new Button();
                console.FlatStyle = FlatStyle.Flat;
                console.BackColor = Color.FromArgb(192, 255, 255);
                console.Font = new Font("Microsoft Sans Serif", 10);
                console.Text = "Console";
                console.Click += (Object sender, EventArgs args) =>
                {
                    if (running.Contains(mainPanel.Name)) consoles.SelectedTab = consoles_[running.IndexOf(mainPanel.Name)];
                };
                console.Size = new Size(70, 43);
                console.Location = new Point(467, 3);
                mainPanel.Controls.Add(console);

                Button options = new Button();
                options.FlatStyle = FlatStyle.Flat;
                options.BackColor = Color.FromArgb(192, 255, 255);
                options.Font = new Font("Yu Gothic UI Semibold", 12, FontStyle.Bold);
                options.Text = "...";
                options.Click += (Object sender, EventArgs args) =>
                {
                    ServerOptions so = new ServerOptions(this, imported.Name == "imported", imported.Text);
                    so.Text = mainPanel.Name + " - Options" + (imported.Name == "imported" ? " - imported" : "");
                    so.Name = mainPanel.Name;
                    using (StreamReader sr = new StreamReader(fi.FullName))
                    {
                        FileInfo fii = new FileInfo(sr.ReadLine());
                        so.dirPath = fii.DirectoryName;
                    }
                    so.Show();
                    this.Enabled = false;
                    so.FormClosed += (o, ex) =>
                    {
                        if (so.deleted) LoadServers();
                    };
                };
                options.Size = new Size(35, 43);
                options.Location = new Point(539, 3);
                mainPanel.Controls.Add(options);

                ServerList.Controls.Add(mainPanel);
                i++;
            }
        }

        private void port_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(port.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                port.Text = port.Text.Remove(port.Text.Length - 1);
                port.SelectionStart = port.Text.Length;
            }
            if (port.Text.Length > 5)
            {
                MessageBox.Show("Max length 5 characters.");
                port.Text = port.Text.Remove(port.Text.Length - 1);
                port.SelectionStart = port.Text.Length;
            }
        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            LoadServers();
        }

        private void StartRam_ValueChanged(object sender, EventArgs e)
        {
            StartRam.Value = StartRam.Value > MaxRam.Value ? MaxRam.Value : StartRam.Value;
        }

        private void MaxRam_ValueChanged(object sender, EventArgs e)
        {
            MaxRam.Value = StartRam.Value > MaxRam.Value ? StartRam.Value : MaxRam.Value;
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (running.Count != 0)
            {
                MessageBox.Show("Please close all the servers!", "WARNING");
                e.Cancel = true;
            }
        }

        private void SavedSeeds_Click(object sender, EventArgs e)
        {
            SeedLoader sl = new SeedLoader(this, seed);
            sl.Show();
            this.Enabled = false;
        }

        private void tips_Click(object sender, EventArgs e)
        {
            Tooltips tt = new Tooltips(this);
            tt.Show();
            this.Enabled = false;
        }

        private void Ports_Click(object sender, EventArgs e)
        {
            PortManager pm = new PortManager(this);
            pm.Show();
            this.Enabled = false;
        }

        private void GetCurrentIP_Click(object sender, EventArgs e)
        {
            IP.Text = GetIPAddress();
        }

        static string GetIPAddress()
        {
            String address = "";
            WebRequest request = WebRequest.Create("http://checkip.dyndns.org/");
            using (WebResponse response = request.GetResponse())
            using (StreamReader stream = new StreamReader(response.GetResponseStream()))
            {
                address = stream.ReadToEnd();
            }

            int first = address.IndexOf("Address: ") + 9;
            int last = address.LastIndexOf("</body>");
            address = address.Substring(first, last - first);

            return address;
        }

        private void IP_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Clipboard.SetText(IP.Text);
        }
    }
}
