﻿using Mono.Nat;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v2
{
    public partial class ServerOptions : Form
    {
        private Form f;
        public string dirPath;
        private string[] prop;
        public bool deleted = false;
        private bool imp = false;
        public string versionT;
        public bool verChanged = false;
        private int prevPort = 0;
        public ServerOptions(Form form,bool imported,string ver)
        {
            InitializeComponent();
            f = form;
            imp = imported;
            versionT = ver;
        }
        private void ServerOptions_Load(object sender, EventArgs e)
        {
            try
            {
                properties.LoadFile(dirPath + "\\server.properties", RichTextBoxStreamType.PlainText);
            }
            catch
            {
                properties.Text = "Can't load...";
                panel2.Enabled = false;
            }
            prop = properties.Lines;
            if(prop.Length < 6)
            {
                MessageBox.Show("Please first start the server or complete the properties file to change the properties.","WARNING");
                panel2.Enabled = false;
                EnableProperties.Enabled = false;
            }
            else prevPort = int.Parse(prop[32].Split('=')[1]);
        }
        private void Cancel_Click(object sender, EventArgs e)
        {
            f.Enabled = true;
            this.Dispose();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            f.Enabled = true;
        }
        private void OpenDirectory_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(dirPath);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"ERROR");
            }
        }
        private void Advanced_Click(object sender, EventArgs e)
        {
            if(Advanced.Text == "Advanced >>>")
            {
                this.Size = new Size(715,403);
                Advanced.Text = "Advanced <<<";
            }
            else 
            {
                this.Size = new Size(390, 403);
                Advanced.Text = "Advanced >>>";
            }
        }
        private void EnableProperties_CheckedChanged(object sender, EventArgs e)
        {
            if (EnableProperties.Checked) properties.ReadOnly = false;
            else properties.ReadOnly = true;
        }
        private void Save_Click(object sender, EventArgs e)
        {
            #region recreate
            if (RecreateWorld.Checked)
            {
                if(worldName.Text == "")
                {
                    MessageBox.Show("Please enter the world name!","WARNING");
                    return;
                }
                if(SimpleServer.running.Contains(this.Name))
                {
                    MessageBox.Show("Please close the server befor deleting the Overworld!", "WARNING");
                    return;
                }
                DialogResult dr = MessageBox.Show("Do you really want to delete [" + worldName.Text +"]'s overwrold forever?\n(That's a long time)","WARNING",MessageBoxButtons.YesNo);
                if (dr == DialogResult.No) return;
                if (dr == DialogResult.Yes) try { Directory.Delete(dirPath + "\\" + worldName.Text, true); } catch { }
            }
            if (RecreateNether.Checked)
            {
                if (worldName.Text == "")
                {
                    MessageBox.Show("Please enter the world name!", "WARNING");
                    return;
                }
                if (SimpleServer.running.Contains(this.Name))
                {
                    MessageBox.Show("Please close the server befor deleting the Nether!", "WARNING");
                    return;
                }
                DialogResult dr = MessageBox.Show("Do you really want to delete [" + worldName.Text + "]'s nether forever?\n(That's a long time)", "WARNING", MessageBoxButtons.YesNo);
                if (dr == DialogResult.No) return;
                if (dr == DialogResult.Yes) try { Directory.Delete(dirPath + "\\" + worldName.Text + "_nether", true); } catch { }
            }
            if (RecreateEnd.Checked)
            {
                if (worldName.Text == "")
                {
                    MessageBox.Show("Please enter the world name!", "WARNING");
                    return;
                }
                if (SimpleServer.running.Contains(this.Name))
                {
                    MessageBox.Show("Please close the server befor deleting the End!", "WARNING");
                    return;
                }
                DialogResult dr = MessageBox.Show("Do you really want to delete [" + worldName.Text + "]'s end forever?\n(That's a long time)", "WARNING", MessageBoxButtons.YesNo);
                if (dr == DialogResult.No) return;
                if (dr == DialogResult.Yes) try { Directory.Delete(dirPath + "\\" + worldName.Text + "_the_end", true); } catch { }
            }
            #endregion
            if(AcceptChanges.Checked)
            {
                using (StreamWriter sw = new StreamWriter(dirPath + "\\server.properties"))
                {
                    sw.Write(properties.Text);
                }
                if(prevPort != int.Parse(port.Text))
                {
                    NatUtility.DeviceFound += (o, ex) =>
                    {
                        INatDevice device = ex.Device;
                        device.DeletePortMap(new Mapping(Protocol.Tcp,prevPort, prevPort));
                        NatUtility.StopDiscovery();
                    };
                    NatUtility.StartDiscovery();
                    NatUtility.DeviceFound += (o, ex) =>
                    {
                        INatDevice device = ex.Device;
                        int port_ = int.Parse(prop[32].Split('=')[1]);
                        device.CreatePortMap(new Mapping(Protocol.Tcp, port_, port_));
                        NatUtility.StopDiscovery();
                    };
                    NatUtility.StartDiscovery();
                }
            }
            if(ChangeDisplayName.Checked)
            {
                if (!SimpleServer.running.Contains(this.Name))
                {
                    if (ServerName.Text == "") MessageBox.Show("Please enter the server name.", "WARNING");
                    else
                    {
                        File.Move(DefaultFiles.StartUpLoadServers + "\\" + this.Name, DefaultFiles.StartUpLoadServers + "\\" + ServerName.Text);
                        MessageBox.Show(this.Name);
                        DirectoryInfo di = new DirectoryInfo(dirPath);
                        Directory.Move(dirPath, di.Parent.FullName + "\\" + ServerName.Text);
                        string[] lines;
                        using (StreamReader sr = new StreamReader(DefaultFiles.StartUpLoadServers + "\\" + ServerName.Text))
                        {
                            lines = sr.ReadToEnd().Split('\n', '\r');
                        }
                        using (StreamWriter sw = new StreamWriter(DefaultFiles.StartUpLoadServers + "\\" + ServerName.Text))
                        {
                            sw.WriteLine(di.Parent.FullName + "\\" + ServerName.Text + "\\" + "start.bat");
                            int i = 0;
                            foreach (string ss in lines)
                            {
                                if (ss != "" && i != 0)
                                {
                                    sw.WriteLine(lines[i]);
                                }
                                i++;
                            }
                        }
                    }
                }
                else MessageBox.Show("Stop the server to change the name.", "WARNING");
            }
            f.Enabled = true;
            SimpleServer s = (SimpleServer)f;
            s.LoadServers();
            this.Dispose();
        }

        private void port_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(port.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                port.Text = port.Text.Remove(port.Text.Length - 1);
                port.SelectionStart = port.Text.Length;
                return;
            }
            if (port.Text.Length > 5)
            {
                MessageBox.Show("Max length 5 characters.");
                port.Text = port.Text.Remove(port.Text.Length - 1);
                port.SelectionStart = port.Text.Length;
                return;
            }
            prop[32] = "server-port=" + port.Text;
            properties.Lines = prop;
        }

        private void seed_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(port.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                seed.Text = seed.Text.Remove(seed.Text.Length - 1);
                seed.SelectionStart = seed.Text.Length;
                return;
            }
            prop[46] = "level-seed=" + seed.Text;
            properties.Lines = prop;
        }

        private void MaxPlayers_ValueChanged(object sender, EventArgs e)
        {
            prop[27] = "max-players=" + MaxPlayers.Value;
            properties.Lines = prop;
        }

        private void OnlineMode_CheckedChanged(object sender, EventArgs e)
        {
            prop[44] = "online-mode=" + OnlineMode.Checked;
            properties.Lines = prop;
        }

        private void CommandBlocks_CheckedChanged(object sender, EventArgs e)
        {
            prop[25] = "enable-command-block=" + CommandBlocks.Checked;
            properties.Lines = prop;
        }

        private void Hardcore_CheckedChanged(object sender, EventArgs e)
        {
            prop[24] = "hardcore=" + Hardcore.Checked;
            properties.Lines = prop;
        }

        private void motd_TextChanged(object sender, EventArgs e)
        {
            prop[50] = "motd=" + motd.Text;
            properties.Lines = prop;
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you really want to delete [" + this.Name + "] server?","WARNING",MessageBoxButtons.YesNo);
            if (dr == DialogResult.No) return;
            if(dr == DialogResult.Yes)
            {
                if (SimpleServer.running.Contains(this.ServerName.Name))
                {
                    MessageBox.Show("Please close the server befor deleting the server!", "WARNING");
                    return;
                }
                if (imp)
                {
                    DialogResult drr = MessageBox.Show("Delete the directory of the imported server?", "WARNING", MessageBoxButtons.YesNo);
                    if (drr == DialogResult.Yes) imp = false;
                }
                if (imp)
                {
                    string path = "";
                    using (StreamReader sr = new StreamReader(DefaultFiles.StartUpLoadServers + "\\" + this.Name))
                    {
                        path = sr.ReadLine();
                    }
                    FileInfo fi = new FileInfo(path);
                    string[] batFile;
                    using (StreamReader sr = new StreamReader(fi.FullName))
                    {
                        batFile = sr.ReadToEnd().Split('\n','\r');
                    }
                    using (StreamWriter sw = new StreamWriter(fi.FullName))
                    {
                        foreach(string s in batFile)
                        {
                            List<string> nogui = s.Split(' ').ToList<string>();
                            if (nogui.Contains("nogui"))
                            {
                                string noguiLine = "";
                                foreach (string ss in nogui)
                                {
                                    if (ss == "nogui") continue;
                                    noguiLine += ss + " ";
                                }
                                sw.WriteLine(noguiLine);
                                continue;
                            }
                            if (s != "") sw.WriteLine(s);
                        }
                    }
                    File.Delete(DefaultFiles.StartUpLoadServers + "\\" + this.Name);
                    deleted = true;
                    f.Enabled = true;
                    this.Close();
                    this.Dispose();
                }
                else
                {
                    try
                    {
                        Directory.Delete(dirPath, true);
                        File.Delete(DefaultFiles.StartUpLoadServers + "\\" + this.Name);
                        deleted = true;
                        f.Enabled = true;
                        DelPort(prevPort);
                    }
                    catch (Exception ex){ MessageBox.Show(ex.Message); }
                    this.Close();
                    this.Dispose();
                }
            }    
        }

        private void DelPort(int port)
        {
            NatUtility.DeviceFound += (o, ex) =>
            {
                INatDevice device = ex.Device;
                device.DeletePortMap(new Mapping(Protocol.Tcp, port, port));
            };
            NatUtility.StartDiscovery();
        }

        private void ServerName_TextChanged(object sender, EventArgs e)
        {
            if (ServerName.Text.Length > 50)
            {
                MessageBox.Show("Name too long!\nMax 50 characters.", "WARNING");
                return;
            }
        }
    }
}
