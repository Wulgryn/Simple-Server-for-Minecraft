﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    public partial class PortType : Form
    {
        public PortType()
        {
            InitializeComponent();
            DefaultDatas dd = new DefaultDatas();
        }

        private void PortType_Load(object sender, EventArgs e)
        {
            if (!DefaultDatas.PortTYPE.Equals(""))
            {
                SimpleServer_v3 ss = new SimpleServer_v3();
                ss.Show();
                this.Dispose();
            }
        }

        private void upnp_Click(object sender, EventArgs e)
        {
            DialogResult upnp_isOn = MessageBox.Show("Are you sure that the UPNP is on?", "WARNING", MessageBoxButtons.YesNo);
            if (upnp_isOn == DialogResult.No) return;
            if (upnp_isOn == DialogResult.Yes)
            {
                using (StreamWriter sw = new StreamWriter(DefaultDatas.registry))
                {
                    sw.WriteLine("UPNP");
                    sw.WriteLine(DefaultDatas.ServerPath);
                    sw.WriteLine(DefaultDatas.Port);
                    sw.WriteLine(DefaultDatas.maxRam);
                    sw.WriteLine(DefaultDatas.startRam);
                    sw.WriteLine(DefaultDatas.nogui);
                    sw.WriteLine(DefaultDatas.KeepDefWorldPath);
                    sw.WriteLine(DefaultDatas.DefWorldPath);
                }
                DefaultDatas.PortTYPE = "upnp";
                SimpleServer_v3 ss = new SimpleServer_v3();
                ss.Show();
                this.Dispose();
            }
        }

        private void ngrok_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            NgrokChecker nc = new NgrokChecker(this,true);
            nc.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mport_Click(object sender, EventArgs e)
        {
            DialogResult upnp_isOn = MessageBox.Show("Are you sure about that?", "WARNING", MessageBoxButtons.YesNo);
            if (upnp_isOn == DialogResult.No) return;
            if (upnp_isOn == DialogResult.Yes)
            {
                using (StreamWriter sw = new StreamWriter(DefaultDatas.registry))
                {
                    sw.WriteLine("manual port");
                    sw.WriteLine(DefaultDatas.ServerPath);
                    sw.WriteLine(DefaultDatas.Port);
                    sw.WriteLine(DefaultDatas.maxRam);
                    sw.WriteLine(DefaultDatas.startRam);
                    sw.WriteLine(DefaultDatas.nogui);
                }
                DefaultDatas.PortTYPE = "manual port";
                SimpleServer_v3 ss = new SimpleServer_v3();
                ss.Show();
                this.Dispose();
            }
        }
    }
}
