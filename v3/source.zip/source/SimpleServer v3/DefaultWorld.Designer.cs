﻿
namespace SimpleServer_v3
{
    partial class DefaultWorld
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DefWorldPath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BrowseMC = new System.Windows.Forms.Button();
            this.Browse = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Ok = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.SetDefault = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // DefWorldPath
            // 
            this.DefWorldPath.Location = new System.Drawing.Point(9, 33);
            this.DefWorldPath.Name = "DefWorldPath";
            this.DefWorldPath.ReadOnly = true;
            this.DefWorldPath.Size = new System.Drawing.Size(469, 20);
            this.DefWorldPath.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(183, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Default world for the server:";
            // 
            // BrowseMC
            // 
            this.BrowseMC.Location = new System.Drawing.Point(9, 76);
            this.BrowseMC.Name = "BrowseMC";
            this.BrowseMC.Size = new System.Drawing.Size(215, 25);
            this.BrowseMC.TabIndex = 2;
            this.BrowseMC.Text = "Browse in minecraft save files";
            this.BrowseMC.UseVisualStyleBackColor = true;
            this.BrowseMC.Click += new System.EventHandler(this.BrowseMC_Click);
            // 
            // Browse
            // 
            this.Browse.Location = new System.Drawing.Point(230, 76);
            this.Browse.Name = "Browse";
            this.Browse.Size = new System.Drawing.Size(125, 25);
            this.Browse.TabIndex = 3;
            this.Browse.Text = "Browse";
            this.Browse.UseVisualStyleBackColor = true;
            this.Browse.Click += new System.EventHandler(this.Browse_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(12, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(313, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Choose the \"session.lock\" file in the world folder.";
            // 
            // Ok
            // 
            this.Ok.Location = new System.Drawing.Point(403, 78);
            this.Ok.Name = "Ok";
            this.Ok.Size = new System.Drawing.Size(75, 23);
            this.Ok.TabIndex = 5;
            this.Ok.Text = "Ok";
            this.Ok.UseVisualStyleBackColor = true;
            this.Ok.Click += new System.EventHandler(this.Ok_Click);
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(493, 78);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 6;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // Clear
            // 
            this.Clear.Location = new System.Drawing.Point(496, 33);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(75, 23);
            this.Clear.TabIndex = 7;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // SetDefault
            // 
            this.SetDefault.AutoSize = true;
            this.SetDefault.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.SetDefault.Location = new System.Drawing.Point(422, 5);
            this.SetDefault.Name = "SetDefault";
            this.SetDefault.Size = new System.Drawing.Size(149, 21);
            this.SetDefault.TabIndex = 8;
            this.SetDefault.Text = "Keep this to default";
            this.SetDefault.UseVisualStyleBackColor = true;
            // 
            // DefaultWorld
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(577, 106);
            this.Controls.Add(this.SetDefault);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.Ok);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Browse);
            this.Controls.Add(this.BrowseMC);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DefWorldPath);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.Name = "DefaultWorld";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DefaultWorld";
            this.Load += new System.EventHandler(this.DefaultWorld_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox DefWorldPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BrowseMC;
        private System.Windows.Forms.Button Browse;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Ok;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.CheckBox SetDefault;
    }
}