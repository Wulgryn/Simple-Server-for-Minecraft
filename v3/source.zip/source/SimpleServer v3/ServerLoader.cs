﻿using Mono.Nat;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    class ServerLoader
    {
        SimpleServer_v3 f;
        Panel list;

        public static List<string> serversList = new List<string>();
        public static List<string> state = new List<string>();

        public ServerLoader(SimpleServer_v3 f, Panel list)
        {
            this.f = f;
            this.list = list;
            Load();
        }

        private void Load()
        {
            list.Controls.Clear();

            string[] files = Directory.GetFiles(DefaultDatas.LoadServersBin);
            if (files.Length == 0)
            {
                Label noServer = new Label();
                noServer.Text = "There aren't any servers here. Why don't you create one?";
                noServer.ForeColor = Color.White;
                noServer.AutoSize = true;
                noServer.Location = new Point(12, 16);
                list.Controls.Add(noServer);
                return;
            }
            int i = 0;
            foreach (string s in files)
            {
                FileInfo fi = new FileInfo(s);
                string startPath;
                string Version;
                string Created;
                string LastUsed;
                string port;
                string name_ = Path.GetFileNameWithoutExtension(fi.Name);
                using (StreamReader sr = new StreamReader(fi.FullName))
                {
                    startPath = sr.ReadLine();
                    Version = sr.ReadLine();
                    Created = sr.ReadLine();
                    LastUsed = sr.ReadLine();
                    port = sr.ReadLine();
                }

                if (!serversList.Contains(name_))
                {
                    serversList.Add(name_);
                    state.Add("STOP");
                }



                Panel mainPanel = new Panel();
                mainPanel.Name = name_;
                mainPanel.Size = new Size(682, 50);
                mainPanel.Location = new Point(0, 17 + 60 * i);
                switch (state[serversList.IndexOf(name_)])
                {
                    case "CRASH":
                        mainPanel.BackColor = Color.FromArgb(255, 128, 128);
                        break;
                    case "RUN":
                        mainPanel.BackColor = Color.FromArgb(128, 255, 128);
                        break;
                    case "STOP":
                        mainPanel.BackColor = Color.FromArgb(255, 192, 128);
                        break;
                }
                list.Controls.Add(mainPanel);

                Label name = new Label();
                name.Location = new Point(3, 5);
                name.Size = new Size(680, 17);
                name.Font = new Font("Arial", 10);
                name.Text = name_;
                mainPanel.Controls.Add(name);

                Label from = new Label();
                from.Text = Version;
                from.Font = new Font("Arial", 8.25f);
                from.Location = new Point(3, 35);
                from.AutoSize = true;
                from.ForeColor = Color.Gray;
                mainPanel.Controls.Add(from);

                Label made = new Label();
                made.Text = Created;
                made.Size = new Size(153, 13);
                made.Location = new Point(95, 35);
                made.ForeColor = Color.Navy;
                made.Font = new Font("Arial", 10, FontStyle.Bold);
                mainPanel.Controls.Add(made);

                Label used = new Label();
                used.Text = LastUsed;
                used.Font = new Font("Arial", 10, FontStyle.Bold);
                used.Location = new Point(280, 35);
                used.Size = new Size(153, 13);
                used.ForeColor = Color.FromArgb(128, 128, 255);
                mainPanel.Controls.Add(used);

                Panel buttons = new Panel();
                buttons.Name = "buttons";
                buttons.Location = new Point(455, 25);
                buttons.Size = new Size(228, 25);
                mainPanel.Controls.Add(buttons);

                Button startstop = new Button();
                startstop.Name = "ss";
                startstop.FlatStyle = FlatStyle.Flat;
                startstop.BackColor = Color.FromArgb(225, 225, 128);
                switch (state[serversList.IndexOf(name_)])
                {
                    case "RUN":
                        startstop.Text = "Stop";
                        startstop.BackColor = Color.FromArgb(255, 192, 192);
                        startstop.Enabled = false;
                        break;
                    case "CRASH":
                        startstop.Text = "Stop";
                        startstop.BackColor = Color.FromArgb(255, 192, 192);
                        startstop.Enabled = false;
                        break;
                    case "STOP":
                        startstop.Text = "Start";
                        startstop.BackColor = Color.FromArgb(225, 225, 128);
                        startstop.Enabled = true;
                        break;
                }
                startstop.Dock = DockStyle.Right;
                startstop.Size = new Size(76, 25);
                Start_Strop_Server sss = null;
                startstop.Click += (o, ex) =>
                {
                    if (DefaultDatas.PortTYPE.Equals("UPNP"))
                    {
                        NatUtility.DeviceFound += (o_, ex_) =>
                        {
                            INatDevice device = ex_.Device;
                            device.CreatePortMap(new Mapping(Protocol.Tcp, int.Parse(port), int.Parse(port)));
                            NatUtility.StopDiscovery();
                        };
                        NatUtility.StartDiscovery();
                    }

                    sss = new Start_Strop_Server(name_, list, int.Parse(port));
                    startstop.Enabled = false;
                    sss.Start();
                    state[serversList.IndexOf(name_)] = "RUN";
                    startstop.Text = "Stop";
                    startstop.BackColor = Color.FromArgb(255, 192, 192);
                    mainPanel.BackColor = Color.FromArgb(128, 255, 128);
                    used.Text = DateTime.Now.ToString();
                    string[] datas;
                    using (StreamReader sr = new StreamReader(DefaultDatas.LoadServersBin + "\\" + name_ + ".smsr"))
                    {
                        datas = sr.ReadToEnd().Split('\r', '\n');
                    }
                    using (StreamWriter sw = new StreamWriter(DefaultDatas.LoadServersBin + "\\" + name_ + ".smsr"))
                    {
                        int j = 0;
                        foreach (string d in datas)
                        {
                            if (d != "")
                            {
                                if (j == 3)
                                {
                                    sw.WriteLine(DateTime.Now);
                                }
                                else sw.WriteLine(d);
                                j++;
                            }
                        }

                    }
                };
                buttons.Controls.Add(startstop);

                Button console = new Button();
                console.Text = "Console";
                console.FlatStyle = FlatStyle.Flat;
                console.BackColor = Color.FromArgb(225, 225, 128);
                console.Dock = DockStyle.Right;
                console.Size = new Size(76, 25);
                console.Click += (o, ex) =>
                {
                    if (sss != null) sss.Select();
                };
                buttons.Controls.Add(console);

                Button options = new Button();
                options.Text = "Options";
                options.FlatStyle = FlatStyle.Flat;
                options.BackColor = Color.FromArgb(225, 225, 128);
                options.Dock = DockStyle.Right;
                options.Size = new Size(76, 25);
                options.Click += (o, ex) =>
                {
                    options.Enabled = false;
                    ServerOptions so = new ServerOptions(options, name_, Version.Split(' ')[0].Equals("Imported"), f);
                    so.Show();
                };
                buttons.Controls.Add(options);


                i++;
            }
        }
    }
}
