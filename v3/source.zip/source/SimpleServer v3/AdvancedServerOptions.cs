﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    public partial class AdvancedServerOptions : Form
    {
        Button b;
        public AdvancedServerOptions(Button b)
        {
            InitializeComponent();
            this.b = b;
            if(DefaultDatas.PortTYPE == "ngrok")
            {
                port.Enabled = false;
            }
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            b.Enabled = true;
        }

        private void StartRAM_ValueChanged(object sender, EventArgs e)
        {
            if (StartRAM.Value > MaxRAM.Value) StartRAM.Value = MaxRAM.Value;
        }

        private void MaxRAM_ValueChanged(object sender, EventArgs e)
        {
            if (MaxRAM.Value < StartRAM.Value) MaxRAM.Value = StartRAM.Value;
        }

        private void AdvancedServerOptions_Load(object sender, EventArgs e)
        {
            MaxRAM.Value = DefaultDatas.maxRam;
            StartRAM.Value = DefaultDatas.startRam;
            port.Text = DefaultDatas.Port.ToString();
            Nogui.Checked = DefaultDatas.nogui;
        }

        private void port_TextChanged(object sender, EventArgs e)
        {
            if (port.Text.Length < 1) save.Enabled = false;
            else save.Enabled = true;
            if(port.Text.Length > 5)
            {
                MessageBox.Show("Please enter only 5 numbers.");
                port.Text = port.Text.Remove(port.Text.Length - 1);
                port.Select(port.Text.Length, 0);
            }
            if (Regex.IsMatch(port.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                port.Text = port.Text.Remove(port.Text.Length - 1);
                port.Select(port.Text.Length, 0);
            }
        }

        private void port_Click(object sender, EventArgs e)
        {
            port.Select(port.Text.Length, 0);
        }

        private void port_KeyPress(object sender, KeyPressEventArgs e)
        {
            port.Select(port.Text.Length, 0);
        }

        private void save_Click(object sender, EventArgs e)
        {
            b.Enabled = true;
            using (StreamWriter sw = new StreamWriter(DefaultDatas.registry))
            {
                sw.WriteLine(DefaultDatas.PortTYPE);
                sw.WriteLine(DefaultDatas.ServerPath);
                sw.WriteLine(port.Text);
                sw.WriteLine(MaxRAM.Value);
                sw.WriteLine(StartRAM.Value);
                sw.WriteLine(Nogui.Checked);
            }
            DefaultDatas.startRam = (int)StartRAM.Value;
            DefaultDatas.maxRam = (int)MaxRAM.Value;
            DefaultDatas.Port = int.Parse(port.Text);
            DefaultDatas.nogui = Nogui.Checked;
            this.Dispose();
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            b.Enabled = true;
            this.Dispose();
        }
    }
}
