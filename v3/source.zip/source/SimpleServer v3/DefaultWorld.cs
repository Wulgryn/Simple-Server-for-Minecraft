﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    public partial class DefaultWorld : Form
    {
        Button b;
        public DefaultWorld(Button b)
        {
            InitializeComponent();
            this.b = b;
        }

        private void DefaultWorld_Load(object sender, EventArgs e)
        {
            DefWorldPath.Text = DefaultDatas.DefWorldPath;
            SetDefault.Checked = DefaultDatas.KeepDefWorldPath;
        }

        private void BrowseMC_Click(object sender, EventArgs e)
        {
            string mcpath = DefaultDatas.Appdata + "\\.minecraft\\saves";
            if (!Directory.Exists(mcpath))
            {
                MessageBox.Show(".minecraft folder doesn't exist.", "ERROR");
                return;
            }
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.InitialDirectory = mcpath;
            ofd.Filter = "LOCK files (*.lock)|*.lock";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                DefWorldPath.Text = new FileInfo(ofd.FileName).DirectoryName;
                DefaultDatas.DefWorldPath = new FileInfo(ofd.FileName).DirectoryName;
            }
        }

        private void Browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "LOCK files (*.lock)|*.lock";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                DefWorldPath.Text = new FileInfo(ofd.FileName).DirectoryName;
                DefaultDatas.DefWorldPath = new FileInfo(ofd.FileName).DirectoryName;
            }
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            if(!SetDefault.Checked)DefaultDatas.DefWorldPath = "";
            b.Enabled = true;
            this.Dispose();
        }

        private void Ok_Click(object sender, EventArgs e)
        {
            DefaultDatas.KeepDefWorldPath = SetDefault.Checked;
            using (StreamWriter sw = new StreamWriter(DefaultDatas.registry))
            {
                sw.WriteLine(DefaultDatas.PortTYPE);
                sw.WriteLine(DefaultDatas.ServerPath);
                sw.WriteLine(DefaultDatas.Port);
                sw.WriteLine(DefaultDatas.maxRam);
                sw.WriteLine(DefaultDatas.startRam);
                sw.WriteLine(DefaultDatas.nogui);
                sw.WriteLine(DefaultDatas.KeepDefWorldPath);
                if (DefaultDatas.KeepDefWorldPath) sw.WriteLine(DefaultDatas.DefWorldPath);
            }
            b.Enabled = true;
            this.Dispose();
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            DefaultDatas.DefWorldPath = "";
            DefWorldPath.Text = "";
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            MessageBox.Show("You have to press the \"Ok\" button to save.", "WARNING");
            b.Enabled = true;
        }
    }
}
