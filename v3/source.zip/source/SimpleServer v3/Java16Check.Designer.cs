﻿
namespace SimpleServer_v3
{
    partial class Java16Check
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.JAVAPath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Browse = new System.Windows.Forms.Button();
            this.Check = new System.Windows.Forms.Button();
            this.NoJava = new System.Windows.Forms.Label();
            this.Continue = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Download = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // JAVAPath
            // 
            this.JAVAPath.Location = new System.Drawing.Point(12, 46);
            this.JAVAPath.Name = "JAVAPath";
            this.JAVAPath.ReadOnly = true;
            this.JAVAPath.Size = new System.Drawing.Size(395, 20);
            this.JAVAPath.TabIndex = 0;
            this.JAVAPath.Text = "C:\\Program Files\\Java\\jdk-16.0.1";
            this.JAVAPath.TextChanged += new System.EventHandler(this.JAVAPath_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Java 16 path:";
            // 
            // Browse
            // 
            this.Browse.Location = new System.Drawing.Point(413, 44);
            this.Browse.Name = "Browse";
            this.Browse.Size = new System.Drawing.Size(75, 23);
            this.Browse.TabIndex = 2;
            this.Browse.Text = "Browse";
            this.Browse.UseVisualStyleBackColor = true;
            this.Browse.Click += new System.EventHandler(this.Browse_Click);
            // 
            // Check
            // 
            this.Check.Location = new System.Drawing.Point(12, 72);
            this.Check.Name = "Check";
            this.Check.Size = new System.Drawing.Size(75, 23);
            this.Check.TabIndex = 3;
            this.Check.Text = "Check";
            this.Check.UseVisualStyleBackColor = true;
            this.Check.Click += new System.EventHandler(this.Check_Click);
            // 
            // NoJava
            // 
            this.NoJava.AutoSize = true;
            this.NoJava.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NoJava.ForeColor = System.Drawing.Color.Red;
            this.NoJava.Location = new System.Drawing.Point(103, 75);
            this.NoJava.Name = "NoJava";
            this.NoJava.Size = new System.Drawing.Size(167, 17);
            this.NoJava.TabIndex = 4;
            this.NoJava.Text = "Can\'t find java 16.0.1!";
            // 
            // Continue
            // 
            this.Continue.Enabled = false;
            this.Continue.Location = new System.Drawing.Point(413, 72);
            this.Continue.Name = "Continue";
            this.Continue.Size = new System.Drawing.Size(75, 23);
            this.Continue.TabIndex = 5;
            this.Continue.Text = "Continue";
            this.Continue.UseVisualStyleBackColor = true;
            this.Continue.Click += new System.EventHandler(this.Continue_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Download here:";
            // 
            // Download
            // 
            this.Download.AutoSize = true;
            this.Download.Location = new System.Drawing.Point(100, 9);
            this.Download.Name = "Download";
            this.Download.Size = new System.Drawing.Size(353, 13);
            this.Download.TabIndex = 7;
            this.Download.TabStop = true;
            this.Download.Text = "https://www.oracle.com/java/technologies/javase-jdk16-downloads.html";
            this.Download.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Download_LinkClicked);
            // 
            // Java16Check
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 100);
            this.Controls.Add(this.Download);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Continue);
            this.Controls.Add(this.NoJava);
            this.Controls.Add(this.Check);
            this.Controls.Add(this.Browse);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.JAVAPath);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.Name = "Java16Check";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Java16Check";
            this.Load += new System.EventHandler(this.Java16Check_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox JAVAPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Browse;
        private System.Windows.Forms.Button Check;
        private System.Windows.Forms.Label NoJava;
        private System.Windows.Forms.Button Continue;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel Download;
    }
}