﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    class DefaultDatas
    {
        //Appdata path
        public static string Appdata = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        //the app path
        public static string AppPath;
        //the deafult path where the servers will created(default)
        public static string ServersBin;
        //the app will load all the servers from here(imported and created)
        public static string LoadServersBin;
        //The app will load from here and download to here the new versions
        public static string Versions;
        //stores what type of port handle load and server path
        public static string registry;
        //ngrok path
        public static string ngrokPath;
        //ngrok config file
        public static string ngrokCONFIG = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + @"\.ngrok2\ngrok.yml";
        //plugin bin
        public static string PluginBin;
        //seed bin
        public static string SeedBin;


        //the port type load from the file
        public static string PortTYPE;
        //where the server will be created, load from here
        public static string ServerPath;
        //IP
        public static string IP;
        //ngrok process
        public static Process NgrokTunnel;


        //port
        public static int Port;
        //Start ram
        public static int startRam;
        //Max ram
        public static int maxRam;
        //nogui enabled
        public static bool nogui;
        //seed
        public static string Seed;
        //default world path
        public static string DefWorldPath;
        //keep def world path
        public static bool KeepDefWorldPath;

        //console
        public static Panel consoles;
        public static TabControl owner;


        //all the spigot versions and download links
        public static string[][] SpigotVersions = new string[][] {
                                                        new string[]{"1.17","https://download.getbukkit.org/spigot/spigot-1.17.jar"},
                                                        new string[]{"1.16.5","https://cdn.getbukkit.org/spigot/spigot-1.16.5.jar"},
                                                        new string[]{"1.16.4","https://cdn.getbukkit.org/spigot/spigot-1.16.4.jar"},
                                                        new string[]{"1.16.3","https://cdn.getbukkit.org/spigot/spigot-1.16.3.jar"},
                                                        new string[]{"1.16.2","https://cdn.getbukkit.org/spigot/spigot-1.16.2.jar"},
                                                        new string[]{"1.16.1","https://cdn.getbukkit.org/spigot/spigot-1.16.1.jar"},
                                                        new string[]{"1.15.2","https://cdn.getbukkit.org/spigot/spigot-1.15.2.jar"},
                                                        new string[]{"1.15.1","https://cdn.getbukkit.org/spigot/spigot-1.15.1.jar"},
                                                        new string[]{"1.15","https://cdn.getbukkit.org/spigot/spigot-1.15.jar"},
                                                        new string[]{"1.14.4","https://cdn.getbukkit.org/spigot/spigot-1.14.4.jar"},
                                                        new string[]{"1.14.3","https://cdn.getbukkit.org/spigot/spigot-1.14.3.jar"},
                                                        new string[]{"1.14.2","https://cdn.getbukkit.org/spigot/spigot-1.14.2.jar"},
                                                        new string[]{"1.14.1","https://cdn.getbukkit.org/spigot/spigot-1.14.1.jar"},
                                                        new string[]{"1.14","https://cdn.getbukkit.org/spigot/spigot-1.14.jar"},
                                                        new string[]{"1.13.2","https://cdn.getbukkit.org/spigot/spigot-1.13.2.jar"},
                                                        new string[]{"1.13.1","https://cdn.getbukkit.org/spigot/spigot-1.13.1.jar"},
                                                        new string[]{"1.13","https://cdn.getbukkit.org/spigot/spigot-1.13.jar"},
                                                        new string[]{"1.12.2","https://cdn.getbukkit.org/spigot/spigot-1.12.2.jar"},
                                                        new string[]{"1.12.1","https://cdn.getbukkit.org/spigot/spigot-1.12.1.jar"},
                                                        new string[]{"1.12","https://cdn.getbukkit.org/spigot/spigot-1.12.jar"},
                                                        new string[]{"1.11.2","https://cdn.getbukkit.org/spigot/spigot-1.11.2.jar"},
                                                        new string[]{"1.11.1","https://cdn.getbukkit.org/spigot/spigot-1.11.1.jar"},
                                                        new string[]{"1.11","https://cdn.getbukkit.org/spigot/spigot-1.11.jar"},
                                                        new string[]{"1.10.2","https://cdn.getbukkit.org/spigot/spigot-1.10.2-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.10","https://cdn.getbukkit.org/spigot/spigot-1.10-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.9.4","https://cdn.getbukkit.org/spigot/spigot-1.9.4-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.9.2","https://cdn.getbukkit.org/spigot/spigot-1.9.2-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.9","https://cdn.getbukkit.org/spigot/spigot-1.9-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8.8","https://cdn.getbukkit.org/spigot/spigot-1.8.8-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8.7","https://cdn.getbukkit.org/spigot/spigot-1.8.7-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8.6","https://cdn.getbukkit.org/spigot/spigot-1.8.6-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8.5","https://cdn.getbukkit.org/spigot/spigot-1.8.5-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8.4","https://cdn.getbukkit.org/spigot/spigot-1.8.4-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8.3","https://cdn.getbukkit.org/spigot/spigot-1.8.3-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.8","https://cdn.getbukkit.org/spigot/spigot-1.8-R0.1-SNAPSHOT-latest.jar"},
                                                        new string[]{"1.7.10","https://cdn.getbukkit.org/spigot/spigot-1.7.10-SNAPSHOT-b1657.jar"},
                                                        new string[]{"1.7.9","https://cdn.getbukkit.org/spigot/spigot-1.7.9-R0.2-SNAPSHOT.jar"},
                                                        new string[]{"1.7.8","https://cdn.getbukkit.org/spigot/spigot-1.7.8-R0.1-SNAPSHOT.jar"},
                                                        new string[]{"1.7.5","https://cdn.getbukkit.org/spigot/spigot-1.7.5-R0.1-SNAPSHOT-1387.jar"},
                                                        new string[]{"1.7.2","https://cdn.getbukkit.org/spigot/spigot-1.7.2-R0.4-SNAPSHOT-1339.jar"},
                                                        new string[]{"1.6.4","https://cdn.getbukkit.org/spigot/spigot-1.6.4-R2.1-SNAPSHOT.jar"},
                                                        new string[]{"1.6.2","https://cdn.getbukkit.org/spigot/spigot-1.6.2-R1.1-SNAPSHOT.jar"},
                                                        new string[]{"1.5.2","https://cdn.getbukkit.org/spigot/spigot-1.5.2-R1.1-SNAPSHOT.jar"},
                                                        new string[]{"1.5.1","https://cdn.getbukkit.org/spigot/spigot-1.5.1-R0.1-SNAPSHOT.jar"},
                                                        new string[]{"1.4.7","https://cdn.getbukkit.org/spigot/spigot-1.4.7-R1.1-SNAPSHOT.jar"},
                                                        new string[]{"1.4.6","https://cdn.getbukkit.org/spigot/spigot-1.4.6-R0.4-SNAPSHOT.jar"},
                                                                };

        public DefaultDatas()
        {
            AppPath = Appdata + @"\SimpleServer";
            ServersBin = AppPath + @"\bin";
            LoadServersBin = AppPath + @"\servers";
            Versions = AppPath + @"\versions";
            registry = AppPath + @"\registry.smsr";
            ngrokPath = AppPath + @"\ngrok.exe";
            PluginBin = AppPath + @"\plugins";
            SeedBin = AppPath + @"\seeds";

            //test all folder and file if exists
            FolderTester(AppPath);
            FolderTester(ServersBin);
            FolderTester(LoadServersBin);
            FolderTester(Versions);
            FolderTester(PluginBin);
            FolderTester(SeedBin);
            FileTester(registry,"\n" + ServersBin + "\n25565\n2\n2\nTrue\nFalse\n");




            using (StreamReader sr = new StreamReader(registry))
            {
                PortTYPE = sr.ReadLine();
                ServerPath = sr.ReadLine();
                Port = int.Parse(sr.ReadLine());
                maxRam = int.Parse(sr.ReadLine());
                startRam = int.Parse(sr.ReadLine());
                nogui = bool.Parse(sr.ReadLine());
                KeepDefWorldPath = bool.Parse(sr.ReadLine());
                if (KeepDefWorldPath) DefWorldPath = sr.ReadLine();
                else DefWorldPath = "";
            }

            if(!Directory.Exists(ServerPath))
            {
                ServerPath = ServersBin;
                using(StreamWriter sw = new StreamWriter(registry))
                {
                    sw.WriteLine(PortTYPE);
                    sw.WriteLine(ServerPath);
                    sw.WriteLine(Port);
                    sw.WriteLine(maxRam);
                    sw.WriteLine(startRam);
                    sw.WriteLine(nogui);
                    sw.WriteLine(KeepDefWorldPath);
                    sw.WriteLine(DefWorldPath);
                }
            }
        }
        //this will test the file's existing and it can be written
        public static void FileTester(string path,string text)
        {
            if (File.Exists(path)) return;
            using (StreamWriter sr = new StreamWriter(path))
            {
                sr.Write(text);
            }
        }

        //this will test the folder's existing
        public static void FolderTester(string path)
        {
            if (Directory.Exists(path)) return;
            Directory.CreateDirectory(path);
        }

        public static void CopyDirectory(string sourcepath,string destinationpath)
        {
            Directory.CreateDirectory(destinationpath);

            string[] files = Directory.GetFiles(sourcepath);
            string[] dirs = Directory.GetDirectories(sourcepath);

            foreach(string s in files)
            {
                File.Copy(s,destinationpath + "\\" + new FileInfo(s).Name,true);
            }
            foreach(string s in dirs)
            {
                CopyDirectory(s,destinationpath + "\\" + new FileInfo(s).Name);
            }
        }
    }
}
