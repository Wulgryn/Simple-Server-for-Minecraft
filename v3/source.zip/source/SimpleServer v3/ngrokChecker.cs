﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    public partial class NgrokChecker : Form
    {
        Form f;
        WebClient client;
        bool createss;
        public NgrokChecker(Form f,bool createss)
        {
            InitializeComponent();
            this.f = f;
            this.createss = createss;
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            if(client != null)client.CancelAsync();
            f.Enabled = true;
        }
        
        private void Ok_Click(object sender, EventArgs e)
        {
            Ok.Enabled = false;

            if (authtoken.Text == "") return;

            client = new WebClient();

            client.DownloadFileAsync(new Uri("https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-windows-amd64.zip"),DefaultDatas.AppPath + @"\ngrok.zip");

            client.DownloadProgressChanged += (o, ex) =>
            {
                pb.Value = ex.ProgressPercentage;
            };
            client.DownloadFileCompleted += (o, ex) =>
            {
                if(ex.Cancelled)
                {
                    File.Delete(DefaultDatas.AppPath + @"\ngrok.zip");
                    return;
                }
                if(!File.Exists(DefaultDatas.ngrokPath))ZipFile.ExtractToDirectory(DefaultDatas.AppPath + @"\ngrok.zip",DefaultDatas.AppPath);
                File.Delete(DefaultDatas.AppPath + @"\ngrok.zip");

                using(StreamWriter sw = new StreamWriter(DefaultDatas.ngrokCONFIG))
                {
                    sw.WriteLine("authtoken: " + authtoken.Text);
                }

                Process p = new Process();
                p.StartInfo.FileName = DefaultDatas.ngrokPath;
                p.StartInfo.Arguments = "tcp 25565";
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.CreateNoWindow = true;
                p.Start();

                DefaultDatas.NgrokTunnel = p;
                
                DefaultDatas.PortTYPE = "ngrok";

                using (StreamWriter sw = new StreamWriter(DefaultDatas.registry))
                {
                    sw.WriteLine("ngrok");
                    sw.WriteLine(DefaultDatas.ServerPath);
                    sw.WriteLine(DefaultDatas.Port);
                    sw.WriteLine(DefaultDatas.maxRam);
                    sw.WriteLine(DefaultDatas.startRam);
                    sw.WriteLine(DefaultDatas.nogui);
                    sw.WriteLine(DefaultDatas.KeepDefWorldPath);
                    sw.WriteLine(DefaultDatas.DefWorldPath);
                }

                if (createss)
                { 
                    SimpleServer_v3 ss = new SimpleServer_v3();
                    ss.Show();
                }

                this.Dispose();
                f.Dispose();
            };
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            if (client != null) client.CancelAsync();
            f.Enabled = true;
            this.Dispose();
        }

        private void token_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://dashboard.ngrok.com/get-started/your-authtoken");
        }

        private void login_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://dashboard.ngrok.com/login");
        }
    }
}
