﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    public partial class SimpleServer_v3 : Form
    {
        ConsoleWindow cw;
        public SimpleServer_v3()
        {
            InitializeComponent();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            foreach(string s in ServerLoader.serversList)
            {
                if (!ServerLoader.state[ServerLoader.serversList.IndexOf(s)].Equals("STOP"))
                {
                    MessageBox.Show("You should stop all the running servers!", "ERROR/WARNING");
                    e.Cancel = true;
                    return;
                }
            }
            if (DefaultDatas.PortTYPE == "ngrok") try
                {
                    DefaultDatas.NgrokTunnel.Kill();
                }
                catch { }
            Application.Exit();
        }

        private void SimpleServer_v3_Load(object sender, EventArgs e)
        {
            Path_.Text = DefaultDatas.ServerPath;
            if(DefaultDatas.PortTYPE == "ngrok")
            {
                Process p = new Process();
                p.StartInfo.FileName = DefaultDatas.ngrokPath;
                p.StartInfo.Arguments = "tcp 25565";
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.CreateNoWindow = true;
                p.Start();
                DefaultDatas.NgrokTunnel = p;
            }

            foreach(string[] s in DefaultDatas.SpigotVersions)
            {
                Versions.Items.Add(s[0]);
            }
            Versions.SelectedIndex = 0;
            DefaultDatas.consoles = ConsolePanel;
            DefaultDatas.owner = consoles;
            LoadServers();
        }

        private void ServerCreatorHandler_Click(object sender, EventArgs e)
        {
            if(ServerCreatorHandler.Text == "<")
            {
                ServerCreatorPanel.Visible = false;
                this.Size = new Size(this.Width - 347,560);
                ServerCreatorHandler.Text = ">";
                return;
            }
            if (ServerCreatorHandler.Text == ">")
            {
                this.Size = new Size(this.Width + 347, 560);
                ServerCreatorHandler.Text = "<";
                ServerCreatorPanel.Visible = true;
            }
        }

        private void Versions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!File.Exists(DefaultDatas.Versions + @"\" + Versions.SelectedItem.ToString() + @"\spigot.jar"))
            {
                VersionBTN.Text = "Download";
                VersionBTN.BackColor = Color.FromArgb(128, 255, 128);
                VersionDWNLProgress.Value = 0;
                NewServer.ForeColor = Color.Red;
                return;
            }
            VersionBTN.Text = "Delete";
            VersionBTN.BackColor = Color.FromArgb(255, 128, 128);
            VersionDWNLProgress.Value = 100;
            if (EULAAgree.Checked && ServerName.Text != "") NewServer.ForeColor = Color.Green;
        }

        private void VersionBTN_Click(object sender, EventArgs e)
        {
            if(VersionBTN.Text == "Download")
            {
                NewServer.ForeColor = Color.Red;
                WebClient client = new WebClient();
                DefaultDatas.FolderTester(DefaultDatas.Versions + @"\" + Versions.SelectedItem.ToString());
                VerCancel.Visible = true;
                VerCancel.Click += (o, ex) =>
                {
                    client.CancelAsync();
                };
                client.DownloadFileAsync(new Uri(DefaultDatas.SpigotVersions[Versions.SelectedIndex][1]),DefaultDatas.Versions + @"\" + Versions.SelectedItem.ToString() + @"\spigot.jar");
                client.DownloadProgressChanged += (o, ex) =>
                {
                    VersionDWNLProgress.Value = ex.ProgressPercentage;
                };
                client.DownloadFileCompleted += (o, ex) =>
                {
                    if(ex.Cancelled)
                    {
                        Directory.Delete(DefaultDatas.Versions + @"\" + Versions.SelectedItem.ToString(), true);
                        VersionDWNLProgress.Value = 0;
                        VerCancel.Visible = false;
                        return;
                    }
                    VersionDWNLProgress.Value = 100;
                    VersionBTN.Text = "Delete";
                    VersionBTN.BackColor = Color.FromArgb(255, 128, 128);
                    VerCancel.Visible = false;
                    if (EULAAgree.Checked && ServerName.Text != "") NewServer.ForeColor = Color.Green;
                };
            }
            if(VersionBTN.Text == "Delete")
            {
                Directory.Delete(DefaultDatas.Versions + @"\" + Versions.SelectedItem.ToString(), true);
                VersionBTN.Text = "Download";
                VersionBTN.BackColor = Color.FromArgb(128, 255, 128);
                VersionDWNLProgress.Value = 0;
                if (EULAAgree.Checked) NewServer.ForeColor = Color.Red;
            }
        }

        private void eulaLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start(eulaLink.Text);
        }

        private void EULAAgree_CheckedChanged(object sender, EventArgs e)
        {
            if (EULAAgree.Checked)
            {
                EULAAgree.ForeColor = Color.Lime;
                if (VersionBTN.Text == "Delete" && ServerName.Text != "") NewServer.ForeColor = Color.Green;
            }
            else
            {
                EULAAgree.ForeColor = Color.Red;
                NewServer.ForeColor = Color.Red;
            }
        }
        PluginManager pm;
        private void Plugins_Click(object sender, EventArgs e)
        {
            Plugins.Enabled = false;
            pm = new PluginManager(Plugins);
            pm.Show();
        }

        private void BrowsePath_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if(fbd.ShowDialog() == DialogResult.OK)
            {
                DefaultDatas.ServerPath = fbd.SelectedPath;
                using (StreamWriter sw = new StreamWriter(DefaultDatas.registry))
                {
                    sw.WriteLine(DefaultDatas.PortTYPE);
                    sw.WriteLine(DefaultDatas.ServerPath);
                    sw.WriteLine(DefaultDatas.Port);
                    sw.WriteLine(DefaultDatas.maxRam);
                    sw.WriteLine(DefaultDatas.startRam);
                    sw.WriteLine(DefaultDatas.nogui);
                    sw.WriteLine(DefaultDatas.KeepDefWorldPath);
                    sw.WriteLine(DefaultDatas.DefWorldPath);
                }
                Path_.Text = DefaultDatas.ServerPath;
            }
        }

        private void AdvancedOptions_Click(object sender, EventArgs e)
        {
            AdvancedOptions.Enabled = false;
            AdvancedServerOptions aso = new AdvancedServerOptions(AdvancedOptions);
            aso.Show();
        }

        public void LoadServers()
        {
            ServerLoader sl = new ServerLoader(this,ServerList);
        }

        private void ServerName_TextChanged(object sender, EventArgs e)
        {
            if(ServerName.Text.Length > 86)
            {
                MessageBox.Show("Max length: 86 char.", "ERROR");
                ServerName.Text = ServerName.Text.Remove(ServerName.Text.Length - 1);
                ServerName.Select(ServerName.Text.Length, 0);
            }
            if (EULAAgree.Checked && VersionBTN.Text == "Delete" && ServerName.Text != "") NewServer.ForeColor = Color.Green;
            else NewServer.ForeColor = Color.Red;
        }

        private void DefPath_Click(object sender, EventArgs e)
        {
            DefaultDatas.ServerPath = DefaultDatas.ServersBin;
            Path_.Text = DefaultDatas.ServerPath;
            using (StreamWriter sw = new StreamWriter(DefaultDatas.registry))
            {
                sw.WriteLine(DefaultDatas.PortTYPE);
                sw.WriteLine(DefaultDatas.ServerPath);
                sw.WriteLine(DefaultDatas.Port);
                sw.WriteLine(DefaultDatas.maxRam);
                sw.WriteLine(DefaultDatas.startRam);
                sw.WriteLine(DefaultDatas.nogui);
                sw.WriteLine(DefaultDatas.KeepDefWorldPath);
                sw.WriteLine(DefaultDatas.DefWorldPath);
            }
        }

        private void NewServer_Click(object sender, EventArgs e)
        {
            if (NewServer.ForeColor == Color.Red)
            {
                if (ServerName.Text.Equals(""))
                {
                    MessageBox.Show("Invalid server name.","ERROR");
                    return;
                }
                if(VersionBTN.Text.Equals("Download"))
                {
                    MessageBox.Show("Download the version or reinstall it.", "ERROR");
                    return;
                }
                if(!EULAAgree.Checked)
                {
                    MessageBox.Show("Read and agree with the eula.", "ERROR");
                    return;
                }
            }
            EULAAgree.Checked = false;
            if (File.Exists(DefaultDatas.LoadServersBin + "\\" + ServerName.Text + ".smsr"))
            {
                DialogResult dr = MessageBox.Show("Server exist with this name!\nDo you want to overwrite it?", "Warning",MessageBoxButtons.YesNo);
                if(dr != DialogResult.Yes)return;
                if(!ServerLoader.state[ServerLoader.serversList.IndexOf(ServerName.Text)].Equals("STOP"))
                {
                    MessageBox.Show("Server is running, stop it first!", "ERROR");
                    return;
                }
                Directory.Delete(DefaultDatas.ServerPath + "\\" + ServerName.Text,true);
            }
            Directory.CreateDirectory(DefaultDatas.ServerPath + "\\" + ServerName.Text);
            if (Directory.Exists(DefaultDatas.DefWorldPath))
            {
                DefaultDatas.CopyDirectory(DefaultDatas.DefWorldPath,DefaultDatas.ServerPath + "\\" + ServerName.Text + "\\world");
                if(!DefaultDatas.KeepDefWorldPath)DefaultDatas.DefWorldPath = "";
            }
            File.Copy(DefaultDatas.Versions + "\\" + Versions.SelectedItem.ToString() + "\\spigot.jar",DefaultDatas.ServerPath + "\\" + ServerName.Text + "\\spigot.jar",true);
            using (StreamWriter sw = new StreamWriter(DefaultDatas.ServerPath + "\\" + ServerName.Text + "\\start.bat"))
            {
                sw.WriteLine("@echo off");
                sw.WriteLine("java -jar -Xmx" + DefaultDatas.maxRam + "G -Xms" + DefaultDatas.startRam + "G spigot.jar" +(DefaultDatas.nogui == true ? " nogui" : ""));
                sw.WriteLine("PAUSE");
            }
            using (StreamWriter sw = new StreamWriter(DefaultDatas.ServerPath + "\\" + ServerName.Text + "\\eula.txt"))
            {
                sw.WriteLine("#By changing the setting below to TRUE you are indicating your agreement to our EULA (https://account.mojang.com/documents/minecraft_eula).");
                sw.WriteLine("#Mon Jan 01 00:00:00 CEST 2021");
                sw.WriteLine("eula = true");
            }
            using (StreamWriter sw = new StreamWriter(DefaultDatas.ServerPath + "\\" + ServerName.Text + "\\server.properties"))
            {
                sw.WriteLine("#Minecraft server properties");
                sw.WriteLine("#Mon Jan 01 00:00:00 CEST 2021");
                sw.WriteLine("server-port=" + DefaultDatas.Port);
                sw.WriteLine("level-seed=" + DefaultDatas.Seed);
            }
            Directory.CreateDirectory(DefaultDatas.ServerPath + "\\" + ServerName.Text + "\\plugins");
            foreach(string s in PluginManager.pluginsToLoad)
            {
                try
                {
                    string file;
                    using (StreamReader sr = new StreamReader(DefaultDatas.PluginBin + "\\" + s + ".smsr"))
                    {
                        file = sr.ReadLine();
                    }
                    FileInfo fi = new FileInfo(file);
                    File.Copy(file, DefaultDatas.ServerPath + "\\" + ServerName.Text + "\\plugins\\" + fi.Name);
                }
                catch
                {
                    MessageBox.Show("Plugin doesn't exist or being used by another process.","ERROR");
                }
            }
            using (StreamWriter sw = new StreamWriter(DefaultDatas.LoadServersBin + "\\" + ServerName.Text + ".smsr"))
            {
                sw.WriteLine(Path_.Text + "\\" + ServerName.Text + "\\start.bat");
                sw.WriteLine(Versions.SelectedItem.ToString());
                sw.WriteLine(DateTime.Now);
                sw.WriteLine("None");
                sw.WriteLine(DefaultDatas.Port);
            }
            LoadServers();
        }
        SeedManager sm;
        private void LoadSeed_Click(object sender, EventArgs e)
        {
            LoadSeed.Enabled = false;
            sm = new SeedManager(LoadSeed,Seed);
            sm.Show();
        }

        private void Seed_TextChanged(object sender, EventArgs e)
        {
            DefaultDatas.Seed = Seed.Text;
        }

        private void SimpleServer_v3_Enter(object sender, EventArgs e)
        {
            if (Plugins.Enabled == false && pm != null) pm.Focus();
            if (LoadSeed.Enabled == false && sm != null) sm.Focus();
        }

        private void PopConsole_Click(object sender, EventArgs e)
        {
            switch(PopConsole.Text)
            {
                case "[ ]":
                    PopConsole.Text = "] [";
                    MainBossPanel.Location = new Point(MainBossPanel.Location.X - 542,MainBossPanel.Location.Y);
                    ServerCreatorPanel.Location = new Point(ServerCreatorPanel.Location.X - 542,ServerCreatorPanel.Location.Y);
                    this.Location = new Point(this.Location.X + 542, this.Location.Y);
                    this.Size = new Size(this.Width - 542,this.Height);
                    cw = new ConsoleWindow(consoles);
                    cw.serverList = MainBossPanel;
                    cw.ServerCreator = ServerCreatorPanel;
                    cw.f = this;
                    cw.popButton = PopConsole;
                    cw.Show();
                    break;
                case "] [":
                    PopConsole.Text = "[ ]";
                    MainBossPanel.Location = new Point(MainBossPanel.Location.X + 542, MainBossPanel.Location.Y);
                    ServerCreatorPanel.Location = new Point(ServerCreatorPanel.Location.X + 542, ServerCreatorPanel.Location.Y);
                    this.Location = new Point(this.Location.X - 542, this.Location.Y);
                    this.Size = new Size(this.Width + 542, this.Height);
                    cw.Kill(consoles);
                    break;
            }
        }

        private void ImportServer_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "BAT files (*.bat)|*.bat";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                FileInfo fi = new FileInfo(ofd.FileName);
                if (File.Exists(DefaultDatas.LoadServersBin + "\\" + fi.Directory.Name + ".smsr"))
                {
                    DialogResult dr = MessageBox.Show("Server exist with this name!\nDo you want to owervrite it?", "Warning", MessageBoxButtons.YesNo);
                    string path_;
                    using (StreamReader sr = new StreamReader(DefaultDatas.LoadServersBin + "\\" + fi.Directory.Name + ".smsr"))
                    {
                        path_ = sr.ReadLine();
                    }
                    if (dr != DialogResult.Yes) return;
                    if (ServerLoader.serversList.Contains(fi.Directory.Name)) if (!ServerLoader.state[ServerLoader.serversList.IndexOf(fi.Directory.Name)].Equals("STOP"))
                        {
                        MessageBox.Show("Server is running, stop it first!", "ERROR");
                        return;
                    }
                    if(new FileInfo(ofd.FileName).DirectoryName.Equals(path_))
                    {
                        MessageBox.Show("You can't import the same server you created or once imported.","ERROR");
                        return;
                    }
                    Directory.Delete(path_ + "\\" + fi.Directory.Name, true);
                }
                using (StreamWriter sw = new StreamWriter(DefaultDatas.LoadServersBin + "\\" + fi.Directory.Name + ".smsr"))
                {
                    sw.WriteLine(ofd.FileName);
                    sw.WriteLine("Imported");
                    sw.WriteLine(DateTime.Now);
                    sw.WriteLine("None");
                    using (StreamReader sr = new StreamReader(fi.DirectoryName + "\\server.properties"))
                    {
                        bool port = false;
                        foreach(string s in sr.ReadToEnd().Split('\n','\r'))
                        {
                            if(s.Split('=')[0].Equals("server-port"))
                            {
                                sw.WriteLine(s.Split('=')[1]);
                                port = true;
                            }
                        }
                        if (!port) sw.WriteLine("25565");
                    }
                }
                LoadServers();
            }
        }

        private void DefWorld_Click(object sender, EventArgs e)
        {
            DefWorld.Enabled = false;
            DefaultWorld dw = new DefaultWorld(DefWorld);
            dw.Show();
        }

        private void GetIP_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if(DefaultDatas.PortTYPE.Equals("ngrok"))
            {
                Process.Start("http://localhost:4040/inspect/http");
            }
            else
            {
                string externalIpString = new WebClient().DownloadString("http://icanhazip.com").Replace("\\r\\n", "").Replace("\\n", "").Trim();
                var externalIp = IPAddress.Parse(externalIpString);

                using (StreamWriter sw = new StreamWriter(DefaultDatas.AppPath + "\\index.html"))
                {
                    sw.WriteLine("<!DOCTYPE html>");
                    sw.WriteLine("<html>");
                    sw.WriteLine("<head>");
                    sw.WriteLine("<meta charset=\"UTF-8\">");
                    sw.WriteLine("<title>IP</title>");
                    sw.WriteLine("</head>");
                    sw.WriteLine("<body>");
                    sw.WriteLine("<p>" + externalIp.ToString() + "</p>");
                    sw.WriteLine("</body>");
                    sw.WriteLine("</html>");
                }

                Process.Start(DefaultDatas.AppPath + "\\index.html");
            }
        }

        private void Options_Click(object sender, EventArgs e)
        {
            Options.Enabled = false;
            Options o = new Options(Options);
            o.Show();
        }
    }
}
