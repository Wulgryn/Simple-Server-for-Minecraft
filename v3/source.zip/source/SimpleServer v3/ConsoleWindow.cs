﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    public partial class ConsoleWindow : Form
    {
        public Panel serverList;
        public Panel ServerCreator;
        public Form f;
        public Button popButton;

        TabControl tc;
        public ConsoleWindow(TabControl tc)
        {
            InitializeComponent();

            foreach(TabPage tp in tc.TabPages)
            {
                consoles.TabPages.Add(tp);
                RichTextBox rtb = (RichTextBox)tp.Controls.Find("rtb", false)[0];
                rtb.Size = new Size(rtb.Width, this.Height - 80);
            }
            DefaultDatas.owner = consoles;
            this.tc = tc;
        }


        public void Kill(TabControl tc)
        {
            tc.TabPages.Clear();
            foreach (TabPage tp in consoles.TabPages)
            {
                tc.TabPages.Add(tp);
                RichTextBox rtb = (RichTextBox)tp.Controls.Find("rtb", false)[0];
                rtb.Size = new Size(512, 460);
                rtb.SelectionStart = rtb.Text.Length;
                rtb.ScrollToCaret();
            }
            DefaultDatas.owner = tc;
            this.Dispose();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            tc.TabPages.Clear();
            foreach (TabPage tp in consoles.TabPages)
            {
                tc.TabPages.Add(tp);
                RichTextBox rtb = (RichTextBox)tp.Controls.Find("rtb", false)[0];
                rtb.Size = new Size(512, 460);
            }
            DefaultDatas.owner = tc;
            serverList.Location = new Point(serverList.Location.X + 542,serverList.Location.Y);
            ServerCreator.Location = new Point(ServerCreator.Location.X + 542, ServerCreator.Location.Y);
            f.Location = new Point(f.Location.X - 542, f.Location.Y);
            f.Size = new Size(f.Width + 542, f.Height);
            popButton.Text = "[ ]";
        }

        private void ConsoleWindow_Resize(object sender, EventArgs e)
        {
            foreach (TabPage tp in consoles.TabPages)
            {
                RichTextBox rtb = (RichTextBox)tp.Controls.Find("rtb", false)[0];
                rtb.Size = new Size(rtb.Width, this.Height - 80);
            }
        }

        private void ConsoleWindow_Shown(object sender, EventArgs e)
        {
            foreach (TabPage tp in consoles.TabPages)
            {
                RichTextBox rtb = (RichTextBox)tp.Controls.Find("rtb", false)[0];
                rtb.Size = new Size(rtb.Width, this.Height - 80);
            }
        }
    }
}
