﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    public partial class PluginManager : Form
    {
        public static List<string> pluginsToLoad = new List<string>();
        Button b;
        public PluginManager(Button b)
        {
            InitializeComponent();
            this.b = b;
        }

        private void PluginManager_Load(object sender, EventArgs e)
        {
            LoadPlugins();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            b.Enabled = true;
        }

        private void AddPlugin_Click(object sender, EventArgs e)
        {
            PluginAdder pa = new PluginAdder(this);
            pa.Show();
        }

        public void LoadPlugins()
        {
            PluginsList.Controls.Clear();
            string[] files = Directory.GetFiles(DefaultDatas.PluginBin);
            int i = 0;
            foreach(string s in files)
            {
                FileInfo fi = new FileInfo(s);
                Panel mainPanel = new Panel();
                mainPanel.Size = new Size(350,40);
                mainPanel.Location = new Point(0,34 + i * 45);
                mainPanel.BackColor = Color.FromArgb(128,128,255);

                Label name = new Label();
                name.Size = new Size(323,20);
                name.Location = new Point(3,12);
                name.Font = new Font("Arial",12);
                name.Text = Path.GetFileNameWithoutExtension(fi.Name);
                mainPanel.Controls.Add(name);

                CheckBox enablePL = new CheckBox();
                enablePL.Location = new Point(332,16);
                if (pluginsToLoad.Contains(name.Text)) enablePL.Checked = true;
                enablePL.CheckedChanged += (o, ex) =>
                {
                    if(enablePL.Checked)
                    {
                        pluginsToLoad.Add(name.Text);
                    }
                    else
                    {
                        pluginsToLoad.Remove(name.Text);
                    }
                };
                mainPanel.Controls.Add(enablePL);

                LinkLabel del = new LinkLabel();
                del.Text = "Delete";
                del.LinkColor = Color.Red;
                del.Location = new Point(315,0);
                del.LinkClicked += (o, ex) =>
                {
                    DialogResult dr = MessageBox.Show("Are you sure?", "WARNING", MessageBoxButtons.YesNo);
                    if(dr == DialogResult.Yes)
                    {
                        if (pluginsToLoad.Contains(name.Text)) pluginsToLoad.Remove(name.Text);
                        File.Delete(DefaultDatas.PluginBin + "\\" + fi.Name);
                        LoadPlugins();
                    }
                };
                mainPanel.Controls.Add(del);


                PluginsList.Controls.Add(mainPanel);
                i++;
            }
        }
    }
}
