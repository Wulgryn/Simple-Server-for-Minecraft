﻿
namespace SimpleServer_v3
{
    partial class AdvancedServerOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.StartRAM = new System.Windows.Forms.NumericUpDown();
            this.MaxRAM = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.Nogui = new System.Windows.Forms.CheckBox();
            this.port = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cancel = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.StartRAM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxRAM)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Start RAM (Gb):";
            // 
            // StartRAM
            // 
            this.StartRAM.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.StartRAM.Location = new System.Drawing.Point(16, 43);
            this.StartRAM.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.StartRAM.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.StartRAM.Name = "StartRAM";
            this.StartRAM.Size = new System.Drawing.Size(120, 23);
            this.StartRAM.TabIndex = 1;
            this.StartRAM.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.StartRAM.ValueChanged += new System.EventHandler(this.StartRAM_ValueChanged);
            // 
            // MaxRAM
            // 
            this.MaxRAM.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MaxRAM.Location = new System.Drawing.Point(16, 111);
            this.MaxRAM.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.MaxRAM.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.MaxRAM.Name = "MaxRAM";
            this.MaxRAM.Size = new System.Drawing.Size(120, 23);
            this.MaxRAM.TabIndex = 3;
            this.MaxRAM.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.MaxRAM.ValueChanged += new System.EventHandler(this.MaxRAM_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(13, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Max RAM (Gb):";
            // 
            // Nogui
            // 
            this.Nogui.AutoSize = true;
            this.Nogui.Checked = true;
            this.Nogui.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Nogui.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Nogui.Location = new System.Drawing.Point(16, 150);
            this.Nogui.Name = "Nogui";
            this.Nogui.Size = new System.Drawing.Size(64, 21);
            this.Nogui.TabIndex = 4;
            this.Nogui.Text = "Nogui";
            this.Nogui.UseVisualStyleBackColor = true;
            // 
            // port
            // 
            this.port.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.port.Location = new System.Drawing.Point(12, 208);
            this.port.Name = "port";
            this.port.Size = new System.Drawing.Size(100, 23);
            this.port.TabIndex = 5;
            this.port.Text = "25565";
            this.port.Click += new System.EventHandler(this.port_Click);
            this.port.TextChanged += new System.EventHandler(this.port_TextChanged);
            this.port.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.port_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(13, 188);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Port:";
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(93, 242);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 7;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(12, 242);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(75, 23);
            this.save.TabIndex = 8;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // AdvancedServerOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(185, 278);
            this.Controls.Add(this.save);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.port);
            this.Controls.Add(this.Nogui);
            this.Controls.Add(this.MaxRAM);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.StartRAM);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "AdvancedServerOptions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Advanced Server Options";
            this.Load += new System.EventHandler(this.AdvancedServerOptions_Load);
            ((System.ComponentModel.ISupportInitialize)(this.StartRAM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxRAM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown StartRAM;
        private System.Windows.Forms.NumericUpDown MaxRAM;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox Nogui;
        private System.Windows.Forms.TextBox port;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.Button save;
    }
}