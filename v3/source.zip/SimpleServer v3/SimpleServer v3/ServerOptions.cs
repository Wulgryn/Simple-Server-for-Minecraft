﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    public partial class ServerOptions : Form
    {
        List<string[]> datas = new List<string[]>();
        string folder;
        Button b;
        bool askPriority = false;
        bool imported;
        string name;
        SimpleServer_v3 f;
        public ServerOptions(Button b, string name, bool imported,SimpleServer_v3 f)
        {
            InitializeComponent();
            if(DefaultDatas.PortTYPE.Equals("ngrok"))
            {
                Port.Enabled = false;
            }
            this.f = f;
            this.name = name;
            this.imported = imported;
            this.b = b;
            this.Text = name + " - Server Options";
            if (imported)
            {
                this.Text = name + " - Imported Server Options";
                verLab.Visible = true;
                Version.Visible = true;
            }
            foreach (string[] s in DefaultDatas.SpigotVersions)
            {
                Version.Items.Add("Imported - " + s[0]);
            }
            
        }

        private void ServerOptions_Load(object sender, EventArgs e)
        {
            using (StreamReader sr = new StreamReader(DefaultDatas.LoadServersBin + "\\" + name + ".smsr"))
            {
                folder = new FileInfo(sr.ReadLine()).DirectoryName;
                string ver = sr.ReadLine();
                if (imported) Version.SelectedText = ver;
                using (StreamReader sr_ = new StreamReader(folder + "\\server.properties"))
                {
                    properties.Text = sr_.ReadToEnd();
                    string[] raw = properties.Text.Split('\n', '\r');
                    for (int i = 0; i < raw.Length; i++)
                    {
                        if (!raw[i].Equals(" ") && !raw[i].Equals("") && !raw[i].Equals("\n")) datas.Add(raw[i].Split('='));
                    }
                }
            }
            Gamemode.SelectedIndex = 0;
            Difficulity.SelectedIndex = 1;
            Version.SelectedIndex = 0;

            bool levelName = false;
            bool levelSeed = false;
            bool maxplayers = false;
            bool onlineMode = false;
            bool enableCommandBlock = false;
            bool hardcore = false;
            bool enableNether = false;
            bool gamemode = false;
            bool difficulity = false;
            bool motd = false;
            bool port = false;
            for (int i = 0; i < datas.Count; i++)
            {
                if (datas[i].ToList().Contains("level-name"))
                {
                    WorldName.Text = datas[i][1];
                    levelName = true;
                }
                if (datas[i].ToList().Contains("level-seed"))
                {
                    seed.Text = datas[i][1];
                    levelSeed = true;
                }
                if (datas[i].ToList().Contains("max-players"))
                {
                    MaxPlayers.Value = int.Parse(datas[i][1]);
                    maxplayers = true;
                }
                if (datas[i].ToList().Contains("online-mode"))
                {
                    OnlineMode.Checked = bool.Parse(datas[i][1]);
                    onlineMode = true;
                }
                if (datas[i].ToList().Contains("enable-command-block"))
                {
                    EnableCommandBlock.Checked = bool.Parse(datas[i][1]);
                    enableCommandBlock = true;
                }
                if (datas[i].ToList().Contains("hardcore"))
                {
                    Hardcore.Checked = bool.Parse(datas[i][1]);
                    hardcore = true;
                }
                if (datas[i].ToList().Contains("allow-nether"))
                {
                    AllowNether.Checked = bool.Parse(datas[i][1]);
                    enableNether = true;
                }
                if (datas[i].ToList().Contains("gamemode"))
                {
                    Gamemode.SelectedItem = datas[i][1];
                    gamemode = true;
                }
                if (datas[i].ToList().Contains("difficulty"))
                {
                    Difficulity.SelectedItem = datas[i][1];
                    difficulity = true;
                }
                if (datas[i].ToList().Contains("motd"))
                {
                    Motd.Text = datas[i][1];
                    motd = true;
                }
                if (datas[i].ToList().Contains("server-port"))
                {
                    Port.Text = datas[i][1];
                    port = true;
                }
            }
            if (!levelName)
            {
                WorldName.Text = "world";
            }
            if (!levelSeed)
            {
                seed.Text = "";
            }
            if (!maxplayers)
            {
                MaxPlayers.Value = 20;
            }
            if (!onlineMode)
            {
                OnlineMode.Checked = true;
            }
            if (!enableCommandBlock)
            {
                EnableCommandBlock.Checked = false;
            }
            if (!hardcore)
            {
                Hardcore.Checked = false;
            }
            if (!enableNether)
            {
                AllowNether.Checked = true;
            }
            if (!gamemode)
            {
                Gamemode.SelectedIndex = 0;
            }
            if (!difficulity)
            {
                Difficulity.SelectedIndex = 1;
            }
            if (!motd)
            {
                Motd.Text = "A Minecraft Server";
            }
            if (!port)
            {
                Port.Text = "25565";
            }
        }

        private void Advanced_Click(object sender, EventArgs e)
        {
            switch (Advanced.Text)
            {
                case ">>  Advanced  >>":
                    Advanced.Text = "<<  Advanced  <<";
                    this.Size = new Size(843, 407);
                    break;
                case "<<  Advanced  <<":
                    Advanced.Text = ">>  Advanced  >>";
                    this.Size = new Size(506, 407);
                    break;
            }
        }

        private void LoadSeed_Click(object sender, EventArgs e)
        {
            LoadSeed.Enabled = false;
            SeedManager sm = new SeedManager(LoadSeed, seed);
            sm.Show();
        }

        private void Save_Click(object sender, EventArgs e)
        {
            if (askPriority)
            {
                DialogResult dr = MessageBox.Show("Save only the properties text?", "WARNING", MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    using (StreamWriter sw = new StreamWriter(folder + "\\server.properties"))
                    {
                        sw.Write(properties.Text);
                    }
                    string[] datas__;
                    using (StreamReader sr = new StreamReader(DefaultDatas.LoadServersBin + "\\" + name + ".smsr"))
                    {
                        datas__ = sr.ReadToEnd().Split('\r', '\n');
                    }
                    using (StreamWriter sw = new StreamWriter(DefaultDatas.LoadServersBin + "\\" + name + ".smsr"))
                    {
                        int j = 0;
                        foreach (string s in datas__)
                        {
                            if (!s.Equals("") && !s.Equals(" "))
                            {
                                sw.WriteLine(s);
                                j++;
                            }
                            if (j == 1 && imported)
                            {
                                sw.WriteLine(Version.SelectedItem.ToString());
                                j++;
                            }
                            if (j == 4)
                            {
                                sw.WriteLine(Port.Text);
                                break;
                            }
                        }
                    }

                    b.Enabled = true;
                    this.Dispose();
                    return;
                }
            }

            string[] datas_;
            using (StreamReader sr = new StreamReader(DefaultDatas.LoadServersBin + "\\" + name + ".smsr"))
            {
                datas_ = sr.ReadToEnd().Split('\r', '\n');
            }
            using (StreamWriter sw = new StreamWriter(DefaultDatas.LoadServersBin + "\\" + name + ".smsr"))
            {
                int j = 0;
                foreach(string s in datas_)
                {
                    if (!s.Equals("") && !s.Equals(" "))
                    {
                        if (j == 1 && imported)
                        {
                            sw.WriteLine(Version.SelectedItem.ToString());
                        }
                        else if (j == 4)
                        {
                            sw.WriteLine(Port.Text);
                            break;
                        }
                        else sw.WriteLine(s);
                        j++;
                    }
                }
            }

            bool levelName = false;
            bool levelSeed = false;
            bool maxplayers = false;
            bool onlineMode = false;
            bool enableCommandBlock = false;
            bool hardcore = false;
            bool enableNether = false;
            bool gamemode = false;
            bool difficulity = false;
            bool motd = false;
            bool port = false;
            for (int i = 0; i < datas.Count; i++)
            {
                if (datas[i].ToList().Contains("level-name"))
                {
                    datas[i][1] = WorldName.Text;
                    levelName = true;
                }
                if (datas[i].ToList().Contains("level-seed"))
                {
                    datas[i][1] = seed.Text;
                    levelSeed = true;
                }
                if (datas[i].ToList().Contains("max-players"))
                {
                    datas[i][1] = MaxPlayers.Value.ToString();
                    maxplayers = true;
                }
                if (datas[i].ToList().Contains("online-mode"))
                {
                    datas[i][1] = OnlineMode.Checked.ToString();
                    onlineMode = true;
                }
                if (datas[i].ToList().Contains("enable-command-block"))
                {
                    datas[i][1] = EnableCommandBlock.Checked.ToString();
                    enableCommandBlock = true;
                }
                if (datas[i].ToList().Contains("hardcore"))
                {
                    datas[i][1] = Hardcore.Checked.ToString();
                    hardcore = true;
                }
                if (datas[i].ToList().Contains("allow-nether"))
                {
                    datas[i][1] = AllowNether.Checked.ToString();
                    enableNether = true;
                }
                if (datas[i].ToList().Contains("gamemode"))
                {
                    datas[i][1] = Gamemode.SelectedItem.ToString();
                    gamemode = true;
                }
                if (datas[i].ToList().Contains("difficulty"))
                {
                    datas[i][1] = Difficulity.SelectedItem.ToString();
                    difficulity = true;
                }
                if (datas[i].ToList().Contains("motd"))
                {
                    datas[i][1] = Motd.Text;
                    motd = true;
                }
                if (datas[i].ToList().Contains("server-port"))
                {
                    datas[i][1] = Port.Text;
                    port = true;
                }
            }
            if (!levelName)
            {
                datas.Add(new string[] { "level-name", WorldName.Text });
            }
            if (!levelSeed)
            {
                datas.Add(new string[] { "level-seed", seed.Text });
            }
            if (!maxplayers)
            {
                datas.Add(new string[] { "max-players", MaxPlayers.Value.ToString() });
            }
            if (!onlineMode)
            {
                datas.Add(new string[] { "online-mode", OnlineMode.Checked.ToString() });
            }
            if (!enableCommandBlock)
            {
                datas.Add(new string[] { "enable-command-block", EnableCommandBlock.Checked.ToString() });
            }
            if (!hardcore)
            {
                datas.Add(new string[] { "hardcore", Hardcore.Checked.ToString() });
            }
            if (!enableNether)
            {
                datas.Add(new string[] { "allow-nether", AllowNether.Checked.ToString() });
            }
            if (!gamemode)
            {
                datas.Add(new string[] { "gamemode", Gamemode.SelectedItem.ToString() });
            }
            if (!difficulity)
            {
                datas.Add(new string[] { "difficulty", Difficulity.SelectedItem.ToString() });
            }
            if (!motd)
            {
                datas.Add(new string[] { "motd", Motd.Text });
            }
            if (!port)
            {
                datas.Add(new string[] { "server-port", Port.Text });
            }

            using (StreamWriter sw = new StreamWriter(folder + "\\server.properties"))
            {
                foreach (string[] s in datas)
                {
                    if (s.Length > 1) sw.WriteLine(s[0] + "=" + s[1]);
                    else sw.WriteLine(s[0]);
                }
            }

            if (ServerLoader.serversList.Contains(Name)) if (!ServerLoader.state[ServerLoader.serversList.IndexOf(Name)].Equals("STOP")) MessageBox.Show("Some changes will be only available on reload or restart.", "WARNING");
            b.Enabled = true;
            f.LoadServers();
            this.Dispose();
        }

        private void OpenFolder_Click(object sender, EventArgs e)
        {
            Process.Start(folder);
        }

        private void properties_Click(object sender, EventArgs e)
        {
            askPriority = true;
        }

        private void Port_TextChanged(object sender, EventArgs e)
        {
            if (Port.Text.Length < 1) Save.Enabled = false;
            else Save.Enabled = true;
            if (Port.Text.Length > 5)
            {
                MessageBox.Show("Please enter only 5 numbers.");
                Port.Text = Port.Text.Remove(Port.Text.Length - 1);
                Port.Select(Port.Text.Length, 0);
            }
            if (Regex.IsMatch(Port.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter only numbers.");
                Port.Text = Port.Text.Remove(Port.Text.Length - 1);
                Port.Select(Port.Text.Length, 0);
            }
        }

        private void DeleteOverworld_Click(object sender, EventArgs e)
        {
            if (ServerLoader.serversList.Contains(name)) if (!ServerLoader.state[ServerLoader.serversList.IndexOf(name)].Equals("STOP"))
                {
                    MessageBox.Show("Server is currently running!","ERROR");
                    return;
                }
            for (int i = 0; i < datas.Count; i++)
            {
                if (datas[i].ToList().Contains("level-name"))
                {
                    try
                    {
                        DialogResult dr = MessageBox.Show("Are you sure?","WARNING",MessageBoxButtons.YesNo);
                        if(dr == DialogResult.Yes)Directory.Delete(folder + "\\" + datas[i][1], true);
                    }
                    catch { }
                }
            }
        }

        private void DeleteNether_Click(object sender, EventArgs e)
        {
            if (ServerLoader.serversList.Contains(name)) if (!ServerLoader.state[ServerLoader.serversList.IndexOf(name)].Equals("STOP"))
                {
                    MessageBox.Show("Server is currently running!", "ERROR");
                    return;
                }
            for (int i = 0; i < datas.Count; i++)
            {
                if (datas[i].ToList().Contains("level-name"))
                {
                    try
                    {
                        DialogResult dr = MessageBox.Show("Are you sure?", "WARNING", MessageBoxButtons.YesNo);
                        if (dr == DialogResult.Yes) Directory.Delete(folder + "\\" + datas[i][1] + "_nether", true);
                    }
                    catch { }
                }
            }
        }

        private void DeleteEnd_Click(object sender, EventArgs e)
        {
            if (ServerLoader.serversList.Contains(name)) if (!ServerLoader.state[ServerLoader.serversList.IndexOf(name)].Equals("STOP"))
                {
                    MessageBox.Show("Server is currently running!", "ERROR");
                    return;
                }
            for (int i = 0; i < datas.Count; i++)
            {
                if (datas[i].ToList().Contains("level-name"))
                {
                    try
                    {
                        DialogResult dr = MessageBox.Show("Are you sure?", "WARNING", MessageBoxButtons.YesNo);
                        if (dr == DialogResult.Yes) Directory.Delete(folder + "\\" + datas[i][1] + "_the_end", true);
                    }
                    catch { }
                }
            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (ServerLoader.serversList.Contains(name)) if (!ServerLoader.state[ServerLoader.serversList.IndexOf(name)].Equals("STOP"))
                {
                    MessageBox.Show("Server is currently running!", "ERROR");
                    return;
                }
            switch (imported)
            {
                case false:
                    DialogResult dr = MessageBox.Show("Are you sure?", "WARNING", MessageBoxButtons.YesNo);
                    if (dr == DialogResult.Yes)
                    {
                        File.Delete(DefaultDatas.LoadServersBin + "\\" + name + ".smsr");
                        Directory.Delete(folder,true);
                        f.LoadServers();
                        this.Dispose();
                    }
                    break;
                case true:
                    DialogResult dr_ = MessageBox.Show("Are you sure?", "WARNING", MessageBoxButtons.YesNo);
                    if (dr_ == DialogResult.Yes)
                    {
                        DialogResult dr__ = MessageBox.Show("Are you want to delete the imported directory?","WARNING",MessageBoxButtons.YesNo);
                        if(dr__ == DialogResult.Yes)
                        {
                            string path_;
                            using(StreamReader sr = new StreamReader(DefaultDatas.LoadServersBin + "\\" + name + ".smsr"))
                            {
                                path_ = sr.ReadLine();
                            }
                            Directory.Delete(folder,true);
                        }
                        File.Delete(DefaultDatas.LoadServersBin + "\\" + name + ".smsr");
                        f.LoadServers();
                        this.Dispose();
                    }
                    break;
            }
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            b.Enabled = true;
            this.Dispose();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            b.Enabled = true;
        }

        private void ServerStartOptions_Click(object sender, EventArgs e)
        {
            ServerStartOptions sso = new ServerStartOptions(name);
            sso.Show();
        }
    }
}
