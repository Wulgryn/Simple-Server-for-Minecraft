﻿
namespace SimpleServer_v3
{
    partial class ServerOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cancel = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.OpenFolder = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            this.OnlineMode = new System.Windows.Forms.CheckBox();
            this.MaxPlayers = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.EnableCommandBlock = new System.Windows.Forms.CheckBox();
            this.Gamemode = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Difficulity = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Hardcore = new System.Windows.Forms.CheckBox();
            this.AllowNether = new System.Windows.Forms.CheckBox();
            this.Motd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Advanced = new System.Windows.Forms.Button();
            this.WorldName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.seed = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.LoadSeed = new System.Windows.Forms.Button();
            this.Version = new System.Windows.Forms.ComboBox();
            this.verLab = new System.Windows.Forms.Label();
            this.properties = new System.Windows.Forms.RichTextBox();
            this.DeleteOverworld = new System.Windows.Forms.Button();
            this.DeleteNether = new System.Windows.Forms.Button();
            this.DeleteEnd = new System.Windows.Forms.Button();
            this.Port = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ServerStartOptions = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.MaxPlayers)).BeginInit();
            this.SuspendLayout();
            // 
            // Cancel
            // 
            this.Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Cancel.Location = new System.Drawing.Point(387, 344);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 0;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // Save
            // 
            this.Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Save.Location = new System.Drawing.Point(306, 344);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(75, 23);
            this.Save.TabIndex = 1;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // OpenFolder
            // 
            this.OpenFolder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OpenFolder.Location = new System.Drawing.Point(11, 344);
            this.OpenFolder.Name = "OpenFolder";
            this.OpenFolder.Size = new System.Drawing.Size(106, 23);
            this.OpenFolder.TabIndex = 2;
            this.OpenFolder.Text = "Open Folder";
            this.OpenFolder.UseVisualStyleBackColor = true;
            this.OpenFolder.Click += new System.EventHandler(this.OpenFolder_Click);
            // 
            // Delete
            // 
            this.Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Delete.ForeColor = System.Drawing.Color.Red;
            this.Delete.Location = new System.Drawing.Point(182, 344);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(106, 23);
            this.Delete.TabIndex = 3;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // OnlineMode
            // 
            this.OnlineMode.AutoSize = true;
            this.OnlineMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.OnlineMode.Location = new System.Drawing.Point(13, 141);
            this.OnlineMode.Name = "OnlineMode";
            this.OnlineMode.Size = new System.Drawing.Size(107, 21);
            this.OnlineMode.TabIndex = 4;
            this.OnlineMode.Text = "Online mode";
            this.OnlineMode.UseVisualStyleBackColor = true;
            // 
            // MaxPlayers
            // 
            this.MaxPlayers.Location = new System.Drawing.Point(11, 115);
            this.MaxPlayers.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.MaxPlayers.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.MaxPlayers.Name = "MaxPlayers";
            this.MaxPlayers.Size = new System.Drawing.Size(120, 20);
            this.MaxPlayers.TabIndex = 5;
            this.MaxPlayers.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(10, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Max players:";
            // 
            // EnableCommandBlock
            // 
            this.EnableCommandBlock.AutoSize = true;
            this.EnableCommandBlock.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.EnableCommandBlock.Location = new System.Drawing.Point(13, 168);
            this.EnableCommandBlock.Name = "EnableCommandBlock";
            this.EnableCommandBlock.Size = new System.Drawing.Size(173, 21);
            this.EnableCommandBlock.TabIndex = 7;
            this.EnableCommandBlock.Text = "Enable command block";
            this.EnableCommandBlock.UseVisualStyleBackColor = true;
            // 
            // Gamemode
            // 
            this.Gamemode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Gamemode.FormattingEnabled = true;
            this.Gamemode.Items.AddRange(new object[] {
            "survival",
            "creative",
            "spectator",
            "adventurer"});
            this.Gamemode.Location = new System.Drawing.Point(11, 266);
            this.Gamemode.Name = "Gamemode";
            this.Gamemode.Size = new System.Drawing.Size(121, 21);
            this.Gamemode.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(8, 246);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Gamemode:";
            // 
            // Difficulity
            // 
            this.Difficulity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Difficulity.FormattingEnabled = true;
            this.Difficulity.Items.AddRange(new object[] {
            "peaceful",
            "easy",
            "normal",
            "hard"});
            this.Difficulity.Location = new System.Drawing.Point(184, 266);
            this.Difficulity.Name = "Difficulity";
            this.Difficulity.Size = new System.Drawing.Size(121, 21);
            this.Difficulity.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(181, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "Difficulty:";
            // 
            // Hardcore
            // 
            this.Hardcore.AutoSize = true;
            this.Hardcore.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Hardcore.Location = new System.Drawing.Point(13, 195);
            this.Hardcore.Name = "Hardcore";
            this.Hardcore.Size = new System.Drawing.Size(86, 21);
            this.Hardcore.TabIndex = 12;
            this.Hardcore.Text = "Hardcore";
            this.Hardcore.UseVisualStyleBackColor = true;
            // 
            // AllowNether
            // 
            this.AllowNether.AutoSize = true;
            this.AllowNether.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.AllowNether.Location = new System.Drawing.Point(13, 222);
            this.AllowNether.Name = "AllowNether";
            this.AllowNether.Size = new System.Drawing.Size(104, 21);
            this.AllowNether.TabIndex = 13;
            this.AllowNether.Text = "Allow nether";
            this.AllowNether.UseVisualStyleBackColor = true;
            // 
            // Motd
            // 
            this.Motd.Location = new System.Drawing.Point(11, 310);
            this.Motd.Name = "Motd";
            this.Motd.Size = new System.Drawing.Size(277, 20);
            this.Motd.TabIndex = 14;
            this.Motd.Text = "A Minecraft Server";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(8, 290);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 17);
            this.label4.TabIndex = 15;
            this.label4.Text = "Motd:";
            // 
            // Advanced
            // 
            this.Advanced.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Advanced.ForeColor = System.Drawing.Color.Green;
            this.Advanced.Location = new System.Drawing.Point(468, 1);
            this.Advanced.Name = "Advanced";
            this.Advanced.Size = new System.Drawing.Size(22, 366);
            this.Advanced.TabIndex = 16;
            this.Advanced.Text = ">>  Advanced  >>";
            this.Advanced.UseVisualStyleBackColor = true;
            this.Advanced.Click += new System.EventHandler(this.Advanced_Click);
            // 
            // WorldName
            // 
            this.WorldName.Location = new System.Drawing.Point(12, 29);
            this.WorldName.Name = "WorldName";
            this.WorldName.Size = new System.Drawing.Size(450, 20);
            this.WorldName.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(10, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(274, 17);
            this.label5.TabIndex = 18;
            this.label5.Text = "World name (calls when the server starts):";
            // 
            // seed
            // 
            this.seed.Location = new System.Drawing.Point(13, 72);
            this.seed.Name = "seed";
            this.seed.Size = new System.Drawing.Size(349, 20);
            this.seed.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(10, 52);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 17);
            this.label6.TabIndex = 20;
            this.label6.Text = "Seed:";
            // 
            // LoadSeed
            // 
            this.LoadSeed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.LoadSeed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoadSeed.Location = new System.Drawing.Point(368, 69);
            this.LoadSeed.Name = "LoadSeed";
            this.LoadSeed.Size = new System.Drawing.Size(95, 25);
            this.LoadSeed.TabIndex = 21;
            this.LoadSeed.Text = "Seed Manager";
            this.LoadSeed.UseVisualStyleBackColor = false;
            this.LoadSeed.Click += new System.EventHandler(this.LoadSeed_Click);
            // 
            // Version
            // 
            this.Version.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Version.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Version.FormattingEnabled = true;
            this.Version.Items.AddRange(new object[] {
            "Imported"});
            this.Version.Location = new System.Drawing.Point(306, 310);
            this.Version.Name = "Version";
            this.Version.Size = new System.Drawing.Size(156, 21);
            this.Version.TabIndex = 22;
            this.Version.Visible = false;
            // 
            // verLab
            // 
            this.verLab.AutoSize = true;
            this.verLab.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.verLab.Location = new System.Drawing.Point(303, 290);
            this.verLab.Name = "verLab";
            this.verLab.Size = new System.Drawing.Size(60, 17);
            this.verLab.TabIndex = 23;
            this.verLab.Text = "Version:";
            this.verLab.Visible = false;
            // 
            // properties
            // 
            this.properties.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.properties.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.properties.ForeColor = System.Drawing.Color.White;
            this.properties.Location = new System.Drawing.Point(496, 95);
            this.properties.Name = "properties";
            this.properties.Size = new System.Drawing.Size(330, 272);
            this.properties.TabIndex = 24;
            this.properties.Text = "";
            this.properties.Click += new System.EventHandler(this.properties_Click);
            // 
            // DeleteOverworld
            // 
            this.DeleteOverworld.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteOverworld.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.DeleteOverworld.ForeColor = System.Drawing.Color.Red;
            this.DeleteOverworld.Location = new System.Drawing.Point(496, 9);
            this.DeleteOverworld.Name = "DeleteOverworld";
            this.DeleteOverworld.Size = new System.Drawing.Size(106, 23);
            this.DeleteOverworld.TabIndex = 25;
            this.DeleteOverworld.Text = "Delete OverWorld";
            this.DeleteOverworld.UseVisualStyleBackColor = true;
            this.DeleteOverworld.Click += new System.EventHandler(this.DeleteOverworld_Click);
            // 
            // DeleteNether
            // 
            this.DeleteNether.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteNether.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.DeleteNether.ForeColor = System.Drawing.Color.Red;
            this.DeleteNether.Location = new System.Drawing.Point(608, 9);
            this.DeleteNether.Name = "DeleteNether";
            this.DeleteNether.Size = new System.Drawing.Size(106, 23);
            this.DeleteNether.TabIndex = 26;
            this.DeleteNether.Text = "Delete Nether";
            this.DeleteNether.UseVisualStyleBackColor = true;
            this.DeleteNether.Click += new System.EventHandler(this.DeleteNether_Click);
            // 
            // DeleteEnd
            // 
            this.DeleteEnd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.DeleteEnd.ForeColor = System.Drawing.Color.Red;
            this.DeleteEnd.Location = new System.Drawing.Point(720, 9);
            this.DeleteEnd.Name = "DeleteEnd";
            this.DeleteEnd.Size = new System.Drawing.Size(106, 23);
            this.DeleteEnd.TabIndex = 27;
            this.DeleteEnd.Text = "Delete End";
            this.DeleteEnd.UseVisualStyleBackColor = true;
            this.DeleteEnd.Click += new System.EventHandler(this.DeleteEnd_Click);
            // 
            // Port
            // 
            this.Port.Location = new System.Drawing.Point(540, 52);
            this.Port.Name = "Port";
            this.Port.Size = new System.Drawing.Size(96, 20);
            this.Port.TabIndex = 28;
            this.Port.TextChanged += new System.EventHandler(this.Port_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(496, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 17);
            this.label7.TabIndex = 29;
            this.label7.Text = "Port:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(496, 75);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 17);
            this.label8.TabIndex = 30;
            this.label8.Text = "Properties text:";
            // 
            // ServerStartOptions
            // 
            this.ServerStartOptions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ServerStartOptions.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ServerStartOptions.Location = new System.Drawing.Point(311, 262);
            this.ServerStartOptions.Name = "ServerStartOptions";
            this.ServerStartOptions.Size = new System.Drawing.Size(151, 25);
            this.ServerStartOptions.TabIndex = 31;
            this.ServerStartOptions.Text = "Server Start Options";
            this.ServerStartOptions.UseVisualStyleBackColor = false;
            this.ServerStartOptions.Click += new System.EventHandler(this.ServerStartOptions_Click);
            // 
            // ServerOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(490, 368);
            this.Controls.Add(this.ServerStartOptions);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Port);
            this.Controls.Add(this.DeleteEnd);
            this.Controls.Add(this.DeleteNether);
            this.Controls.Add(this.DeleteOverworld);
            this.Controls.Add(this.properties);
            this.Controls.Add(this.verLab);
            this.Controls.Add(this.Version);
            this.Controls.Add(this.LoadSeed);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.seed);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.WorldName);
            this.Controls.Add(this.Advanced);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Motd);
            this.Controls.Add(this.AllowNether);
            this.Controls.Add(this.Hardcore);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Difficulity);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Gamemode);
            this.Controls.Add(this.EnableCommandBlock);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MaxPlayers);
            this.Controls.Add(this.OnlineMode);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.OpenFolder);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.Cancel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "ServerOptions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ServerOptions";
            this.Load += new System.EventHandler(this.ServerOptions_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MaxPlayers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Button OpenFolder;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.CheckBox OnlineMode;
        private System.Windows.Forms.NumericUpDown MaxPlayers;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox EnableCommandBlock;
        private System.Windows.Forms.ComboBox Gamemode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox Difficulity;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox Hardcore;
        private System.Windows.Forms.CheckBox AllowNether;
        private System.Windows.Forms.TextBox Motd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Advanced;
        private System.Windows.Forms.TextBox WorldName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox seed;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button LoadSeed;
        private System.Windows.Forms.ComboBox Version;
        private System.Windows.Forms.Label verLab;
        private System.Windows.Forms.RichTextBox properties;
        private System.Windows.Forms.Button DeleteOverworld;
        private System.Windows.Forms.Button DeleteNether;
        private System.Windows.Forms.Button DeleteEnd;
        private System.Windows.Forms.TextBox Port;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button ServerStartOptions;
    }
}