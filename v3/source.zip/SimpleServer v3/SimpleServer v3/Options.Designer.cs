﻿
namespace SimpleServer_v3
{
    partial class Options
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cancel = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.UPNP = new System.Windows.Forms.RadioButton();
            this.NGROK = new System.Windows.Forms.RadioButton();
            this.MANUALPORT = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // Cancel
            // 
            this.Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Cancel.Location = new System.Drawing.Point(353, 166);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 0;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // Save
            // 
            this.Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Save.Location = new System.Drawing.Point(272, 166);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(75, 23);
            this.Save.TabIndex = 1;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // UPNP
            // 
            this.UPNP.AutoSize = true;
            this.UPNP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.UPNP.Location = new System.Drawing.Point(13, 13);
            this.UPNP.Name = "UPNP";
            this.UPNP.Size = new System.Drawing.Size(64, 21);
            this.UPNP.TabIndex = 2;
            this.UPNP.TabStop = true;
            this.UPNP.Text = "UPNP";
            this.UPNP.UseVisualStyleBackColor = true;
            // 
            // NGROK
            // 
            this.NGROK.AutoSize = true;
            this.NGROK.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NGROK.Location = new System.Drawing.Point(13, 40);
            this.NGROK.Name = "NGROK";
            this.NGROK.Size = new System.Drawing.Size(77, 21);
            this.NGROK.TabIndex = 3;
            this.NGROK.TabStop = true;
            this.NGROK.Text = "NGROK";
            this.NGROK.UseVisualStyleBackColor = true;
            // 
            // MANUALPORT
            // 
            this.MANUALPORT.AutoSize = true;
            this.MANUALPORT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MANUALPORT.Location = new System.Drawing.Point(12, 67);
            this.MANUALPORT.Name = "MANUALPORT";
            this.MANUALPORT.Size = new System.Drawing.Size(126, 21);
            this.MANUALPORT.TabIndex = 4;
            this.MANUALPORT.TabStop = true;
            this.MANUALPORT.Text = "MANUAL PORT";
            this.MANUALPORT.UseVisualStyleBackColor = true;
            // 
            // Options
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(440, 195);
            this.Controls.Add(this.MANUALPORT);
            this.Controls.Add(this.NGROK);
            this.Controls.Add(this.UPNP);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.Cancel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Options";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Options";
            this.Load += new System.EventHandler(this.Options_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.RadioButton UPNP;
        private System.Windows.Forms.RadioButton NGROK;
        private System.Windows.Forms.RadioButton MANUALPORT;
    }
}