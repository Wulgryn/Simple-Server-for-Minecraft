﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    public partial class SeedManager : Form
    {
        Button b;
        TextBox t;
        public SeedManager(Button b,TextBox t)
        {
            InitializeComponent();
            this.b = b;
            this.t = t;
        }

        private void SeedManager_Load(object sender, EventArgs e)
        {
            Loadseeds();
        }

        private void Loadseeds()
        {
            seedlist.Controls.Clear();
            string[] files = Directory.GetFiles(DefaultDatas.SeedBin);
            int i = 0;
            foreach(string s in files)
            {
                FileInfo fi = new FileInfo(s);
                string name = Path.GetFileNameWithoutExtension(fi.Name);
                string seed;
                using (StreamReader sr = new StreamReader(fi.FullName))
                {
                    seed = sr.ReadLine();
                }

                Panel mainPanel = new Panel();
                mainPanel.Size = new Size(301,40);
                mainPanel.Location = new Point(0,i * 45);
                mainPanel.BackColor = Color.FromArgb(128,255,200);
                seedlist.Controls.Add(mainPanel);

                Button set = new Button();
                set.Text = "Set";
                set.Dock = DockStyle.Right;
                set.Size = new Size(42, 40);
                set.FlatStyle = FlatStyle.Flat;
                set.Click += (o, ex) =>
                {
                    t.Text = seed;
                    b.Enabled = true;
                    this.Dispose();
                };
                mainPanel.Controls.Add(set);

                Label n = new Label();
                n.Text = name;
                n.Location = new Point(3, 12);
                n.Size = new Size(216, 17);
                n.Font = new Font("Arial", 10);
                mainPanel.Controls.Add(n);

                Button del = new Button();
                del.Text = "Del";
                del.Dock = DockStyle.Right;
                del.Size = new Size(42, 40);
                del.FlatStyle = FlatStyle.Flat;
                del.Click += (o, ex) =>
                {
                    DialogResult dr = MessageBox.Show("Are you sure?", "WaRNING", MessageBoxButtons.YesNo);
                    if (dr == DialogResult.Yes)
                    {
                        File.Delete(fi.FullName);
                        Loadseeds();
                    }
                };
                mainPanel.Controls.Add(del);

                i++;
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            b.Enabled = true;
        }

        private void add_Click(object sender, EventArgs e)
        {
            if(File.Exists(DefaultDatas.SeedBin + "\\" + Sname.Text + ".smsr"))
            {
                MessageBox.Show("Name taken.","ERROR");
                return;
            }
            using (StreamWriter sw = new StreamWriter(DefaultDatas.SeedBin + "\\" + Sname.Text + ".smsr"))
            {
                sw.WriteLine(Sseed.Text);
            }
            add.Enabled = false;
            Sname.Text = "";
            Sseed.Text = "";
            Loadseeds();
        }

        private void Sname_TextChanged(object sender, EventArgs e)
        {
            if (Sseed.Text != "" && Sname.Text != "") add.Enabled = true;
            else add.Enabled = false;
        }

        private void Sseed_TextChanged(object sender, EventArgs e)
        {
            if (Sseed.Text != "" && Sname.Text != "") add.Enabled = true;
            else add.Enabled = false;
        }
    }
}
