﻿
namespace SimpleServer_v3
{
    partial class SeedManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.seedlist = new System.Windows.Forms.Panel();
            this.add = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Sname = new System.Windows.Forms.TextBox();
            this.Sseed = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // seedlist
            // 
            this.seedlist.AutoScroll = true;
            this.seedlist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.seedlist.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.seedlist.Location = new System.Drawing.Point(0, 86);
            this.seedlist.Name = "seedlist";
            this.seedlist.Size = new System.Drawing.Size(319, 364);
            this.seedlist.TabIndex = 0;
            // 
            // add
            // 
            this.add.BackColor = System.Drawing.Color.Aqua;
            this.add.Enabled = false;
            this.add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add.Location = new System.Drawing.Point(244, 1);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(75, 79);
            this.add.TabIndex = 1;
            this.add.Text = "Add";
            this.add.UseVisualStyleBackColor = false;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(-3, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Seed:";
            // 
            // Sname
            // 
            this.Sname.Location = new System.Drawing.Point(0, 23);
            this.Sname.Name = "Sname";
            this.Sname.Size = new System.Drawing.Size(238, 20);
            this.Sname.TabIndex = 4;
            this.Sname.TextChanged += new System.EventHandler(this.Sname_TextChanged);
            // 
            // Sseed
            // 
            this.Sseed.Location = new System.Drawing.Point(0, 60);
            this.Sseed.Name = "Sseed";
            this.Sseed.Size = new System.Drawing.Size(238, 20);
            this.Sseed.TabIndex = 5;
            this.Sseed.TextChanged += new System.EventHandler(this.Sseed_TextChanged);
            // 
            // SeedManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(319, 450);
            this.Controls.Add(this.Sseed);
            this.Controls.Add(this.Sname);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.add);
            this.Controls.Add(this.seedlist);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "SeedManager";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SeedManager";
            this.Load += new System.EventHandler(this.SeedManager_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel seedlist;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Sname;
        private System.Windows.Forms.TextBox Sseed;
    }
}