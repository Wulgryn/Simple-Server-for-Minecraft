﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    public partial class Java16Check : Form
    {
        string path = @"\bin\javaw.exe";
        public Java16Check()
        {
            InitializeComponent();
        }

        private void Java16Check_Load(object sender, EventArgs e)
        {
            if(File.Exists(JAVAPath.Text + path))
            {
                PortType pt = new PortType();
                pt.Show();
                this.Dispose();
            }
        }

        private void Browse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if(fbd.ShowDialog() == DialogResult.OK)
            {
                JAVAPath.Text = fbd.SelectedPath;
            }
        }

        private void Check_Click(object sender, EventArgs e)
        {
            if(File.Exists(JAVAPath.Text + path))
            {
                NoJava.Visible = false;
                Continue.Enabled = true;
                return;
            }
            NoJava.Visible = true;
            Continue.Enabled = false;
        }

        private void Continue_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You have to restart the SimpleServer client to use 16.0.1","WARNING");
            PortType pt = new PortType();
            pt.Show();
            this.Dispose();
        }

        private void Download_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://www.oracle.com/java/technologies/javase-jdk16-downloads.html");
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            Environment.Exit(0);
        }

        private void JAVAPath_TextChanged(object sender, EventArgs e)
        {
            Continue.Enabled = false;
        }
    }
}
