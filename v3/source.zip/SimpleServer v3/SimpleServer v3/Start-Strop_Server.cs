﻿using Mono.Nat;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    class Start_Strop_Server
    {
        string name;
        Panel owner;

        bool saveseed = false;
        string seedname;

        bool stopserver = false;

        int port;

        TabPage tp_;

        public Start_Strop_Server(string name,Panel owner,int port)
        {
            this.port = port;
            this.name = name;
            this.owner = owner;
        }

        public void Start()
        {
            TabControl tc = DefaultDatas.owner;
            TabPage tp = new TabPage();
            tp.Text = name;
            tp.BackColor = Color.Gray;

            TextBox tb = new TextBox();
            tb.Dock = DockStyle.Bottom;
            tb.BorderStyle = BorderStyle.FixedSingle;
            tb.BackColor = Color.FromArgb(224, 224, 224);
            tb.Location = new Point(3,469);
            tb.Size = new Size(512,20);
            tb.KeyPress += (o, ex) =>
            {
                if (ex.KeyChar == (char)Keys.Enter) ex.Handled = true;
            };
            tp.Controls.Add(tb);
            tp_ = tp;

            RichTextBox rtb = new RichTextBox();
            rtb.Name = "rtb";
            rtb.Dock = DockStyle.Top;
            rtb.BackColor = Color.FromArgb(64, 64, 64);
            rtb.BorderStyle = BorderStyle.None;
            rtb.Dock = DockStyle.Top;
            rtb.Size = new Size(512, 460);
            rtb.ForeColor = Color.FromArgb(224, 224, 224);
            rtb.Font = new Font("Arial", 10);
            rtb.ReadOnly = true;
            rtb.MouseUp += (o, ex) =>
            {
                tb.Focus();
            };
            tp.Controls.Add(rtb);

            tc.TabPages.Add(tp);

            string dir;
            using ( StreamReader sr = new StreamReader(DefaultDatas.LoadServersBin + "\\" + name + ".smsr"))
            {
                dir = sr.ReadLine();
            }

            FileInfo fi = new FileInfo(dir);
            StartProcess(rtb,tb,fi.DirectoryName,tc,tp);
        }

        private void StartProcess(RichTextBox output, TextBox input, string workingDir,TabControl admin,TabPage subadmin)
        {
            Process p = new Process();
            p.StartInfo.WorkingDirectory = workingDir;
            p.StartInfo.FileName = "CMD.exe";
            p.StartInfo.CreateNoWindow = true;
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardInput = true;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.RedirectStandardError = true;
            p.Start();
            p.BeginOutputReadLine();
            p.BeginErrorReadLine();

            //output
            p.OutputDataReceived += (o, ex) =>
            {
                HandleOutput(ex.Data, output,subadmin,admin,p);
            };
            p.ErrorDataReceived += (o, ex) =>
            {
                HandleOutput(ex.Data, output,subadmin,admin,p);
            };
            p.StandardInput.WriteLine("call start.bat");


            //input
            input.KeyDown += (o, ex) =>
            {
                if (ex.KeyCode == Keys.Enter)
                {
                    if(input.Text.Equals("exit"))
                    {
                        stopserver = true;
                        HandleStop();
                        p.StandardInput.WriteLine("stop");
                    }
                    if(input.Text.Equals("close"))
                    {
                        DialogResult dr = MessageBox.Show("\nThis will close the console, but not the server. Only use if the server crashed and not handled!\n\nDo you want to close the console?", "WARNING", MessageBoxButtons.YesNo);
                        if (dr == DialogResult.Yes)
                        {
                            DefaultDatas.owner.Controls.Remove(subadmin);
                            stopserver = true;
                            HandleStop();
                            p.StandardInput.WriteLine("stop");
                        }
                    }    
                    if(input.Text.Equals("stop"))
                    {
                        stopserver = true;
                        p.StandardInput.WriteLine("stop");
                    }


                    string[] cmd = input.Text.Split(':');
                    if (cmd.Length > 1)
                    {
                        string command = cmd[0];
                        if (command.Equals("saveseed"))
                        {
                            saveseed = true;
                            seedname = cmd[1];
                            p.StandardInput.WriteLine("seed");
                            
                        }
                        else
                        {
                            DefaultDatas.consoles.Parent.Invoke(new Action(() =>
                            {
                                output.AppendText("Invalid command." + "\n");
                                output.SelectionStart = output.Text.Length;
                                output.ScrollToCaret();
                            }));
                        }
                        input.Text = "";
                    }


                    p.StandardInput.WriteLine(input.Text);
                    input.Text = "";
                }
            };
        }
        
        private void HandleOutput(string s,RichTextBox output,TabPage subadmin, TabControl admin,Process runPro)
        {
            DefaultDatas.consoles.Parent.Invoke(new Action(() =>
            {
                output.AppendText(s + "\n");
                output.SelectionStart = output.Text.Length;
                output.ScrollToCaret();

                string[] cmd = s.Split(':');
                if(cmd.Length > 1)
                {
                    string command = cmd[cmd.Length - 1];
                    if (command.Equals(" All chunks are saved"))
                    {
                        HandleStop();
                        DefaultDatas.owner.Controls.Remove(subadmin);
                    }
                    if(saveseed && cmd[cmd.Length - 2].Equals(" Seed"))
                    {
                        SaveSeed(seedname,command.Split('[',']',' ')[command.Split('[', ']', ' ').Length - 2]);
                    }
                    if(command.Equals(" Saving worlds") && !stopserver)
                    {
                        HandleCrash(output);
                    }
                }

                cmd = s.Split('[',']');
                if(cmd.Length > 3)
                {
                    if(cmd[3].Equals("main/FATAL"))
                    {
                        HandleCrash(output);
                    }
                }

            }));
        }

        private void HandleCrash(RichTextBox output)
        {
            NatUtility.DeviceFound += (o_, ex_) =>
            {
                INatDevice device = ex_.Device;
                device.DeletePortMap(new Mapping(Protocol.Tcp, port, port));
                NatUtility.StopDiscovery();
            };
            NatUtility.StartDiscovery();
            output.AppendText("\n\nWrite \"close\" to close. It might be running in the back. Recommended to check it.\n\n");
            output.SelectionStart = output.Text.Length;
            output.ScrollToCaret();
            owner.Controls.Find(name,false)[0].BackColor = Color.FromArgb(255, 128, 128);
            ServerLoader.state[ServerLoader.serversList.IndexOf(name)] = "CRASH";
        }

        private void HandleStop()
        {
            NatUtility.DeviceFound += (o_, ex_) =>
            {
                INatDevice device = ex_.Device;
                device.DeletePortMap(new Mapping(Protocol.Tcp, port, port));
                NatUtility.StopDiscovery();
            };
            NatUtility.StartDiscovery();
            owner.Controls.Find(name, false)[0].BackColor = Color.FromArgb(255, 192, 128);
            Button ss = (Button)owner.Controls.Find(name, false)[0].Controls.Find("buttons",false)[0].Controls.Find("ss", false)[0];
            ss.Text = "Start";
            ss.Enabled = true;
            ss.BackColor = Color.FromArgb(225, 225, 128);
            ServerLoader.state[ServerLoader.serversList.IndexOf(name)] = "STOP";
        }

        private void SaveSeed(string name,string seed)
        {
            saveseed = false;
            if(File.Exists(DefaultDatas.SeedBin + "\\" + name + ".smsr"))
            {
                DialogResult dr = MessageBox.Show("Saved seed with this name already exist.\nDo you want to owervrite?", "WARNING", MessageBoxButtons.YesNo);
                if (dr != DialogResult.Yes) return;
            }
            using(StreamWriter sw = new StreamWriter(DefaultDatas.SeedBin + "\\" + name + ".smsr"))
            {
                sw.WriteLine(seed);
            }
        }

        public void Select()
        {
            if(!ServerLoader.state[ServerLoader.serversList.IndexOf(name)].Equals("STOP"))DefaultDatas.owner.SelectedTab = tp_;
        }
    }
}
