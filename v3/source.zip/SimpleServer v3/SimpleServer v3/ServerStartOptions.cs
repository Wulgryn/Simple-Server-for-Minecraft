﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    public partial class ServerStartOptions : Form
    {
        List<string> bat = new List<string>();
        string startfile;
        public ServerStartOptions(string name)
        {
            InitializeComponent();
            using (StreamReader sr = new StreamReader(DefaultDatas.LoadServersBin + "\\" + name + ".smsr"))
            {
                startfile = sr.ReadLine();
            }
            string[] datas;
            using (StreamReader sr = new StreamReader(startfile))
            {
                datas = sr.ReadToEnd().Split('\r', '\n');
            }
            foreach(string s in datas)
            {
                if(!s.Equals("") && !s.Equals(" "))
                {
                    bat.Add(s);
                }
            }
        }

        private void ServerStartOptions_Load(object sender, EventArgs e)
        {
            foreach (string s in bat)
            {
                string[] datas = s.Split(' ');
                if (datas[0].Equals("java"))
                {
                    foreach(string d in datas)
                    {
                        char[] c = d.ToCharArray();
                        if (c.Length > 3)
                        {
                            char[] ccc = new char[] { c[1], c[2], c[3] };
                            if (new string(ccc).Equals("Xmx"))
                            {
                                MaxRam.Value = int.Parse(c[4].ToString());
                            }
                            if (new string(ccc).Equals("Xms"))
                            {
                                StartRam.Value = int.Parse(c[4].ToString());
                            }
                        }
                        if(d.Equals("nogui"))
                        {
                            Nogui.Checked = true;
                        }
                    }
                }
            }
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void Save_Click(object sender, EventArgs e)
        {
            using(StreamWriter sw = new StreamWriter(startfile))
            {
                foreach(string s in bat)
                {
                    if(s.Split(' ').Length > 2)
                    {
                        if(s.Split(' ')[0].Equals("java"))
                        {
                            sw.WriteLine("java -jar -Xmx" + MaxRam.Value + "G -Xms" + StartRam.Value + "G spigot.jar" + (Nogui.Checked ? " nogui" : ""));
                        }
                    }
                    else sw.WriteLine(s);
                }
            }
            MessageBox.Show("Changes will be enabled on server restart!","WARNING");
            this.Dispose();
        }

        private void StartRam_ValueChanged(object sender, EventArgs e)
        {
            if (StartRam.Value > MaxRam.Value) StartRam.Value = MaxRam.Value;
        }

        private void MaxRam_ValueChanged(object sender, EventArgs e)
        {
            if (MaxRam.Value < StartRam.Value) MaxRam.Value = StartRam.Value;
        }
    }
}
