﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    public partial class Options : Form
    {
        Button b;
        string check;
        public Options(Button b)
        {
            InitializeComponent();
            this.b = b;
            using (StreamReader sr = new StreamReader(DefaultDatas.registry))
            {
                switch(sr.ReadLine())
                {
                    case "UPNP":
                        UPNP.Checked = true;
                        check = "UPNP";
                        break;
                    case "ngrok":
                        NGROK.Checked = true;
                        check = "ngrok";
                        break;
                    case "manual port":
                        MANUALPORT.Checked = true;
                        check = "manual port";
                        break;
                }
            }
        }

        private void Options_Load(object sender, EventArgs e)
        {

        }

        private void Save_Click(object sender, EventArgs e)
        {
            using (StreamWriter sw = new StreamWriter(DefaultDatas.registry))
            {
                sw.WriteLine(UPNP.Checked ? "UPNP" : NGROK.Checked ? "ngrok" : "manual port");
                sw.WriteLine(DefaultDatas.ServerPath);
                sw.WriteLine(DefaultDatas.Port);
                sw.WriteLine(DefaultDatas.maxRam);
                sw.WriteLine(DefaultDatas.startRam);
                sw.WriteLine(DefaultDatas.nogui);
                sw.WriteLine(DefaultDatas.KeepDefWorldPath);
                sw.WriteLine(DefaultDatas.DefWorldPath);
            }
            if ((!check.Equals("ngrok") && NGROK.Checked))
            {
                NgrokChecker nc = new NgrokChecker(this, false);
                nc.Show();
            }
            if ((check.Equals("UPNP") && !UPNP.Checked) || (check.Equals("ngrok") && !NGROK.Checked) || (check.Equals("manual port") && !MANUALPORT.Checked)) MessageBox.Show("To enable changes restart the SimpleServer client.","WARNING");
            
            b.Enabled = true;
            this.Dispose();
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            b.Enabled = true;
            this.Dispose();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            b.Enabled = true;
        }
    }
}
