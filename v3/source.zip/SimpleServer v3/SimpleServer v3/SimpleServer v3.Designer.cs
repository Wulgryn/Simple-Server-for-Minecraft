﻿
namespace SimpleServer_v3
{
    partial class SimpleServer_v3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ServerCreatorPanel = new System.Windows.Forms.Panel();
            this.DefWorld = new System.Windows.Forms.Button();
            this.Seed = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.LoadSeed = new System.Windows.Forms.Button();
            this.DefPath = new System.Windows.Forms.Button();
            this.ServerName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.AdvancedOptions = new System.Windows.Forms.Button();
            this.BrowsePath = new System.Windows.Forms.Button();
            this.Path_ = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Plugins = new System.Windows.Forms.Button();
            this.eulaLink = new System.Windows.Forms.LinkLabel();
            this.EULAAgree = new System.Windows.Forms.CheckBox();
            this.VerCancel = new System.Windows.Forms.Button();
            this.VersionDWNLProgress = new System.Windows.Forms.ProgressBar();
            this.VersionBTN = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Versions = new System.Windows.Forms.ComboBox();
            this.ImportServer = new System.Windows.Forms.Button();
            this.NewServer = new System.Windows.Forms.Button();
            this.ServerCreatorHandler = new System.Windows.Forms.Button();
            this.MainBossPanel = new System.Windows.Forms.Panel();
            this.Options = new System.Windows.Forms.Button();
            this.GetIP = new System.Windows.Forms.LinkLabel();
            this.PopConsole = new System.Windows.Forms.Button();
            this.ConsolePanel = new System.Windows.Forms.Panel();
            this.consoles = new System.Windows.Forms.TabControl();
            this.ServerList = new System.Windows.Forms.Panel();
            this.ServerCreatorPanel.SuspendLayout();
            this.MainBossPanel.SuspendLayout();
            this.ConsolePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // ServerCreatorPanel
            // 
            this.ServerCreatorPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ServerCreatorPanel.Controls.Add(this.DefWorld);
            this.ServerCreatorPanel.Controls.Add(this.Seed);
            this.ServerCreatorPanel.Controls.Add(this.label5);
            this.ServerCreatorPanel.Controls.Add(this.LoadSeed);
            this.ServerCreatorPanel.Controls.Add(this.DefPath);
            this.ServerCreatorPanel.Controls.Add(this.ServerName);
            this.ServerCreatorPanel.Controls.Add(this.label4);
            this.ServerCreatorPanel.Controls.Add(this.label3);
            this.ServerCreatorPanel.Controls.Add(this.AdvancedOptions);
            this.ServerCreatorPanel.Controls.Add(this.BrowsePath);
            this.ServerCreatorPanel.Controls.Add(this.Path_);
            this.ServerCreatorPanel.Controls.Add(this.label2);
            this.ServerCreatorPanel.Controls.Add(this.Plugins);
            this.ServerCreatorPanel.Controls.Add(this.eulaLink);
            this.ServerCreatorPanel.Controls.Add(this.EULAAgree);
            this.ServerCreatorPanel.Controls.Add(this.VerCancel);
            this.ServerCreatorPanel.Controls.Add(this.VersionDWNLProgress);
            this.ServerCreatorPanel.Controls.Add(this.VersionBTN);
            this.ServerCreatorPanel.Controls.Add(this.label1);
            this.ServerCreatorPanel.Controls.Add(this.Versions);
            this.ServerCreatorPanel.Controls.Add(this.ImportServer);
            this.ServerCreatorPanel.Controls.Add(this.NewServer);
            this.ServerCreatorPanel.Location = new System.Drawing.Point(1281, 0);
            this.ServerCreatorPanel.Name = "ServerCreatorPanel";
            this.ServerCreatorPanel.Size = new System.Drawing.Size(353, 521);
            this.ServerCreatorPanel.TabIndex = 0;
            // 
            // DefWorld
            // 
            this.DefWorld.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.DefWorld.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DefWorld.Location = new System.Drawing.Point(121, 332);
            this.DefWorld.Name = "DefWorld";
            this.DefWorld.Size = new System.Drawing.Size(114, 28);
            this.DefWorld.TabIndex = 20;
            this.DefWorld.Text = "Default World";
            this.DefWorld.UseVisualStyleBackColor = false;
            this.DefWorld.Click += new System.EventHandler(this.DefWorld_Click);
            // 
            // Seed
            // 
            this.Seed.Location = new System.Drawing.Point(67, 366);
            this.Seed.Name = "Seed";
            this.Seed.Size = new System.Drawing.Size(267, 20);
            this.Seed.TabIndex = 19;
            this.Seed.TextChanged += new System.EventHandler(this.Seed_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(16, 367);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 17);
            this.label5.TabIndex = 18;
            this.label5.Text = "Seed:";
            // 
            // LoadSeed
            // 
            this.LoadSeed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.LoadSeed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoadSeed.Location = new System.Drawing.Point(241, 332);
            this.LoadSeed.Name = "LoadSeed";
            this.LoadSeed.Size = new System.Drawing.Size(95, 28);
            this.LoadSeed.TabIndex = 17;
            this.LoadSeed.Text = "Seed Manager";
            this.LoadSeed.UseVisualStyleBackColor = false;
            this.LoadSeed.Click += new System.EventHandler(this.LoadSeed_Click);
            // 
            // DefPath
            // 
            this.DefPath.BackColor = System.Drawing.Color.Gray;
            this.DefPath.FlatAppearance.BorderSize = 0;
            this.DefPath.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DefPath.Location = new System.Drawing.Point(270, 440);
            this.DefPath.Name = "DefPath";
            this.DefPath.Size = new System.Drawing.Size(64, 23);
            this.DefPath.TabIndex = 16;
            this.DefPath.Text = "Default";
            this.DefPath.UseVisualStyleBackColor = false;
            this.DefPath.Click += new System.EventHandler(this.DefPath_Click);
            // 
            // ServerName
            // 
            this.ServerName.Location = new System.Drawing.Point(19, 167);
            this.ServerName.Name = "ServerName";
            this.ServerName.Size = new System.Drawing.Size(315, 20);
            this.ServerName.TabIndex = 15;
            this.ServerName.Text = "Untitled";
            this.ServerName.TextChanged += new System.EventHandler(this.ServerName_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(14, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 17);
            this.label4.TabIndex = 14;
            this.label4.Text = "Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label3.Location = new System.Drawing.Point(18, 234);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Download percentage:";
            // 
            // AdvancedOptions
            // 
            this.AdvancedOptions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.AdvancedOptions.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AdvancedOptions.Font = new System.Drawing.Font("Nirmala UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdvancedOptions.Location = new System.Drawing.Point(17, 474);
            this.AdvancedOptions.Name = "AdvancedOptions";
            this.AdvancedOptions.Size = new System.Drawing.Size(317, 35);
            this.AdvancedOptions.TabIndex = 12;
            this.AdvancedOptions.Text = "Advanced Options";
            this.AdvancedOptions.UseVisualStyleBackColor = false;
            this.AdvancedOptions.Click += new System.EventHandler(this.AdvancedOptions_Click);
            // 
            // BrowsePath
            // 
            this.BrowsePath.BackColor = System.Drawing.Color.Gray;
            this.BrowsePath.FlatAppearance.BorderSize = 0;
            this.BrowsePath.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BrowsePath.Location = new System.Drawing.Point(17, 440);
            this.BrowsePath.Name = "BrowsePath";
            this.BrowsePath.Size = new System.Drawing.Size(64, 23);
            this.BrowsePath.TabIndex = 11;
            this.BrowsePath.Text = "Browse";
            this.BrowsePath.UseVisualStyleBackColor = false;
            this.BrowsePath.Click += new System.EventHandler(this.BrowsePath_Click);
            // 
            // Path_
            // 
            this.Path_.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Path_.Location = new System.Drawing.Point(17, 414);
            this.Path_.Name = "Path_";
            this.Path_.ReadOnly = true;
            this.Path_.Size = new System.Drawing.Size(317, 20);
            this.Path_.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(14, 394);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(273, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "The path where the server will be created:";
            // 
            // Plugins
            // 
            this.Plugins.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Plugins.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Plugins.Location = new System.Drawing.Point(19, 332);
            this.Plugins.Name = "Plugins";
            this.Plugins.Size = new System.Drawing.Size(96, 28);
            this.Plugins.TabIndex = 8;
            this.Plugins.Text = "Plugin Manager";
            this.Plugins.UseVisualStyleBackColor = false;
            this.Plugins.Click += new System.EventHandler(this.Plugins_Click);
            // 
            // eulaLink
            // 
            this.eulaLink.AutoSize = true;
            this.eulaLink.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.eulaLink.LinkColor = System.Drawing.Color.Cyan;
            this.eulaLink.Location = new System.Drawing.Point(18, 302);
            this.eulaLink.Name = "eulaLink";
            this.eulaLink.Size = new System.Drawing.Size(306, 15);
            this.eulaLink.TabIndex = 7;
            this.eulaLink.TabStop = true;
            this.eulaLink.Text = "https://account.mojang.com/documents/minecraft_eula";
            this.eulaLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.eulaLink_LinkClicked);
            // 
            // EULAAgree
            // 
            this.EULAAgree.AutoSize = true;
            this.EULAAgree.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.EULAAgree.ForeColor = System.Drawing.Color.Red;
            this.EULAAgree.Location = new System.Drawing.Point(21, 278);
            this.EULAAgree.Name = "EULAAgree";
            this.EULAAgree.Size = new System.Drawing.Size(121, 21);
            this.EULAAgree.TabIndex = 6;
            this.EULAAgree.Text = "Agree to EULA";
            this.EULAAgree.UseVisualStyleBackColor = true;
            this.EULAAgree.CheckedChanged += new System.EventHandler(this.EULAAgree_CheckedChanged);
            // 
            // VerCancel
            // 
            this.VerCancel.BackColor = System.Drawing.Color.Silver;
            this.VerCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.VerCancel.Location = new System.Drawing.Point(270, 249);
            this.VerCancel.Name = "VerCancel";
            this.VerCancel.Size = new System.Drawing.Size(68, 23);
            this.VerCancel.TabIndex = 3;
            this.VerCancel.Text = "Cancel";
            this.VerCancel.UseVisualStyleBackColor = false;
            this.VerCancel.Visible = false;
            // 
            // VersionDWNLProgress
            // 
            this.VersionDWNLProgress.Location = new System.Drawing.Point(21, 249);
            this.VersionDWNLProgress.Name = "VersionDWNLProgress";
            this.VersionDWNLProgress.Size = new System.Drawing.Size(243, 23);
            this.VersionDWNLProgress.TabIndex = 5;
            // 
            // VersionBTN
            // 
            this.VersionBTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.VersionBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.VersionBTN.Location = new System.Drawing.Point(270, 210);
            this.VersionBTN.Name = "VersionBTN";
            this.VersionBTN.Size = new System.Drawing.Size(68, 23);
            this.VersionBTN.TabIndex = 4;
            this.VersionBTN.Text = "Download";
            this.VersionBTN.UseVisualStyleBackColor = false;
            this.VersionBTN.Click += new System.EventHandler(this.VersionBTN_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(16, 190);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Version:";
            // 
            // Versions
            // 
            this.Versions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Versions.FormattingEnabled = true;
            this.Versions.Location = new System.Drawing.Point(21, 210);
            this.Versions.Name = "Versions";
            this.Versions.Size = new System.Drawing.Size(243, 21);
            this.Versions.TabIndex = 2;
            this.Versions.SelectedIndexChanged += new System.EventHandler(this.Versions_SelectedIndexChanged);
            // 
            // ImportServer
            // 
            this.ImportServer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ImportServer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ImportServer.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ImportServer.Location = new System.Drawing.Point(14, 97);
            this.ImportServer.Name = "ImportServer";
            this.ImportServer.Size = new System.Drawing.Size(320, 43);
            this.ImportServer.TabIndex = 1;
            this.ImportServer.Text = "Import";
            this.ImportServer.UseVisualStyleBackColor = false;
            this.ImportServer.Click += new System.EventHandler(this.ImportServer_Click);
            // 
            // NewServer
            // 
            this.NewServer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.NewServer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewServer.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.NewServer.ForeColor = System.Drawing.Color.Red;
            this.NewServer.Location = new System.Drawing.Point(14, 12);
            this.NewServer.Name = "NewServer";
            this.NewServer.Size = new System.Drawing.Size(320, 79);
            this.NewServer.TabIndex = 0;
            this.NewServer.Text = "New";
            this.NewServer.UseVisualStyleBackColor = false;
            this.NewServer.Click += new System.EventHandler(this.NewServer_Click);
            // 
            // ServerCreatorHandler
            // 
            this.ServerCreatorHandler.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ServerCreatorHandler.Location = new System.Drawing.Point(1257, 458);
            this.ServerCreatorHandler.Name = "ServerCreatorHandler";
            this.ServerCreatorHandler.Size = new System.Drawing.Size(30, 63);
            this.ServerCreatorHandler.TabIndex = 1;
            this.ServerCreatorHandler.Text = "<";
            this.ServerCreatorHandler.UseVisualStyleBackColor = true;
            this.ServerCreatorHandler.Click += new System.EventHandler(this.ServerCreatorHandler_Click);
            // 
            // MainBossPanel
            // 
            this.MainBossPanel.BackColor = System.Drawing.Color.Gray;
            this.MainBossPanel.Controls.Add(this.Options);
            this.MainBossPanel.Controls.Add(this.GetIP);
            this.MainBossPanel.Controls.Add(this.PopConsole);
            this.MainBossPanel.Controls.Add(this.ConsolePanel);
            this.MainBossPanel.Controls.Add(this.ServerList);
            this.MainBossPanel.Controls.Add(this.ServerCreatorHandler);
            this.MainBossPanel.Location = new System.Drawing.Point(0, 0);
            this.MainBossPanel.Name = "MainBossPanel";
            this.MainBossPanel.Size = new System.Drawing.Size(1287, 521);
            this.MainBossPanel.TabIndex = 3;
            // 
            // Options
            // 
            this.Options.BackColor = System.Drawing.Color.Silver;
            this.Options.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Options.Location = new System.Drawing.Point(1260, 0);
            this.Options.Name = "Options";
            this.Options.Size = new System.Drawing.Size(27, 23);
            this.Options.TabIndex = 6;
            this.Options.Text = "O";
            this.Options.UseVisualStyleBackColor = false;
            this.Options.Click += new System.EventHandler(this.Options_Click);
            // 
            // GetIP
            // 
            this.GetIP.AutoSize = true;
            this.GetIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.GetIP.LinkColor = System.Drawing.Color.Blue;
            this.GetIP.Location = new System.Drawing.Point(575, 3);
            this.GetIP.Name = "GetIP";
            this.GetIP.Size = new System.Drawing.Size(47, 17);
            this.GetIP.TabIndex = 0;
            this.GetIP.TabStop = true;
            this.GetIP.Text = "Get IP";
            this.GetIP.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.GetIP_LinkClicked);
            // 
            // PopConsole
            // 
            this.PopConsole.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PopConsole.Location = new System.Drawing.Point(542, 0);
            this.PopConsole.Name = "PopConsole";
            this.PopConsole.Size = new System.Drawing.Size(27, 23);
            this.PopConsole.TabIndex = 5;
            this.PopConsole.Text = "[ ]";
            this.PopConsole.UseVisualStyleBackColor = true;
            this.PopConsole.Click += new System.EventHandler(this.PopConsole_Click);
            // 
            // ConsolePanel
            // 
            this.ConsolePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ConsolePanel.Controls.Add(this.consoles);
            this.ConsolePanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.ConsolePanel.Location = new System.Drawing.Point(0, 0);
            this.ConsolePanel.Name = "ConsolePanel";
            this.ConsolePanel.Size = new System.Drawing.Size(542, 521);
            this.ConsolePanel.TabIndex = 4;
            // 
            // consoles
            // 
            this.consoles.Location = new System.Drawing.Point(0, 0);
            this.consoles.Name = "consoles";
            this.consoles.SelectedIndex = 0;
            this.consoles.Size = new System.Drawing.Size(526, 518);
            this.consoles.TabIndex = 3;
            // 
            // ServerList
            // 
            this.ServerList.AutoScroll = true;
            this.ServerList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ServerList.Location = new System.Drawing.Point(561, 23);
            this.ServerList.Name = "ServerList";
            this.ServerList.Size = new System.Drawing.Size(700, 498);
            this.ServerList.TabIndex = 2;
            // 
            // SimpleServer_v3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1634, 521);
            this.Controls.Add(this.MainBossPanel);
            this.Controls.Add(this.ServerCreatorPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SimpleServer_v3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SimpleServer v3";
            this.Load += new System.EventHandler(this.SimpleServer_v3_Load);
            this.Enter += new System.EventHandler(this.SimpleServer_v3_Enter);
            this.ServerCreatorPanel.ResumeLayout(false);
            this.ServerCreatorPanel.PerformLayout();
            this.MainBossPanel.ResumeLayout(false);
            this.MainBossPanel.PerformLayout();
            this.ConsolePanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel ServerCreatorPanel;
        private System.Windows.Forms.Button ImportServer;
        private System.Windows.Forms.Button NewServer;
        private System.Windows.Forms.Button ServerCreatorHandler;
        private System.Windows.Forms.Panel MainBossPanel;
        private System.Windows.Forms.Button VersionBTN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox Versions;
        private System.Windows.Forms.ProgressBar VersionDWNLProgress;
        private System.Windows.Forms.Button VerCancel;
        private System.Windows.Forms.LinkLabel eulaLink;
        private System.Windows.Forms.CheckBox EULAAgree;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Plugins;
        private System.Windows.Forms.Button BrowsePath;
        private System.Windows.Forms.TextBox Path_;
        private System.Windows.Forms.Button AdvancedOptions;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel ServerList;
        private System.Windows.Forms.TextBox ServerName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button DefPath;
        private System.Windows.Forms.Button LoadSeed;
        private System.Windows.Forms.TextBox Seed;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel ConsolePanel;
        private System.Windows.Forms.TabControl consoles;
        private System.Windows.Forms.Button PopConsole;
        private System.Windows.Forms.Button DefWorld;
        private System.Windows.Forms.LinkLabel GetIP;
        private System.Windows.Forms.Button Options;
    }
}