﻿
namespace SimpleServer_v3
{
    partial class ConsoleWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ConsolePanel = new System.Windows.Forms.Panel();
            this.consoles = new System.Windows.Forms.TabControl();
            this.ConsolePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // ConsolePanel
            // 
            this.ConsolePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ConsolePanel.Controls.Add(this.consoles);
            this.ConsolePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ConsolePanel.Location = new System.Drawing.Point(0, 0);
            this.ConsolePanel.Name = "ConsolePanel";
            this.ConsolePanel.Size = new System.Drawing.Size(800, 669);
            this.ConsolePanel.TabIndex = 0;
            // 
            // consoles
            // 
            this.consoles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.consoles.Location = new System.Drawing.Point(0, 0);
            this.consoles.Name = "consoles";
            this.consoles.SelectedIndex = 0;
            this.consoles.Size = new System.Drawing.Size(800, 669);
            this.consoles.TabIndex = 4;
            // 
            // ConsoleWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 669);
            this.Controls.Add(this.ConsolePanel);
            this.Name = "ConsoleWindow";
            this.Text = "ConsoleWindow";
            this.Shown += new System.EventHandler(this.ConsoleWindow_Shown);
            this.Resize += new System.EventHandler(this.ConsoleWindow_Resize);
            this.ConsolePanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel ConsolePanel;
        private System.Windows.Forms.TabControl consoles;
    }
}