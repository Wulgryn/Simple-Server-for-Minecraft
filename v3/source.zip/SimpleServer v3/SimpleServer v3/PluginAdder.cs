﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleServer_v3
{
    public partial class PluginAdder : Form
    {
        PluginManager pm;
        public PluginAdder(PluginManager pm)
        {
            InitializeComponent();
            this.pm = pm;
        }

        private void path_TextChanged(object sender, EventArgs e)
        {
            if (path.Text != "" && name.Text != "") Add.Enabled = true;
            else Add.Enabled = false;
        }

        private void name_TextChanged(object sender, EventArgs e)
        {
            if (path.Text != "" && name.Text != "") Add.Enabled = true;
            else Add.Enabled = false;
        }

        private void browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "JAR files (*.jar)|*.jar";
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                path.Text = ofd.FileName;
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            using(StreamWriter sw = new StreamWriter(DefaultDatas.PluginBin + @"\" + name.Text +".smsr"))
            {
                sw.WriteLine(path.Text);
            }
            pm.LoadPlugins();
            pm.Focus();
            this.Dispose();
        }
    }
}
